/*
Problem Statement: 

Write a program which accept string from user and display only
digits from that string.
Input : “marve89llous121”
Output : 89121
Input : “Demo”
Output :   

*/

#include"Header.h"


int main()
{
	char arr[20];
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	DisplayDigits(arr);
		
	return 0;
}
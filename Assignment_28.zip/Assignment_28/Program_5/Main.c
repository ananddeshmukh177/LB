/*
Problem Statement: 

Write a program which accept string from user and count number of
white spaces
Input : “MarvellouS”
Output : 0
Input : “MarvellouS Infosystems”
Output : 1
Input : “MarvellouS Infosystems by Piyush Manohar Khairnnar”
Output : 5  

*/

#include"Header.h"


int main()
{
	char arr[20];
	int iRet = 0;
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	iRet = SpaceCount(arr);
	
	printf("SpaceCount is : %d",iRet);
		
	return 0;
}
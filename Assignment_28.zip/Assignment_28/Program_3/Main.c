/*
Problem Statement: 

Write a program which accept string from user and toggle the case.
Input : “Marvellous Multi OS”
Output : mARVELLOUS mULTI os  

*/

#include"Header.h"


int main()
{
	char arr[20];
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	StringToggle(arr);
	
	printf("modified string is: %s",arr);
	
	return 0;
}
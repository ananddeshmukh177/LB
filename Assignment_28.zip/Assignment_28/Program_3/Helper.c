#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StringToggle
//Parameters    : char
//Return Value  : void
//Description   : it is used to display Toggle String.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StringToggle(char *cPtr)
{	
	if(cPtr == NULL)
	{
		return;
	}
	
	while(*cPtr != '\0')
	{
		if(*cPtr >= 'a' && *cPtr <= 'z')
		{
			*cPtr = *cPtr-32;
		}
		else if(*cPtr >= 'A' && *cPtr <= 'Z')
		{
			*cPtr = *cPtr+32;
		}
		cPtr++;
	}
}

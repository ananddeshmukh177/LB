/*
Problem Statement: 

Write a program which accept string from user and convert it into lower case.
Input : “Marvellous Multi OS”
Output : marvellous multi os 

*/

#include"Header.h"


int main()
{
	char arr[20];
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	StringLower(arr);
	
	printf("modified string is: %s",arr);
	
	return 0;
}
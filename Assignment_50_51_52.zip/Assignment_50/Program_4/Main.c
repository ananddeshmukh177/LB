/*

3. Write a program which accept file name which contains information of
student and display only names of Marks

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct student
{
	int Rollno;
	char Name[20];
	int Marks;
};

void FileRead(char *name)
{
   int fd = 0, ret = 0, size = 0, i = 0;
   struct student sobj;
    
    fd = open(name,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return ;
    }
    
    printf("Data from file is : \n");
    
    while((ret = read(fd,&sobj,sizeof(sobj)))!= 0)
    {
        //printf("Roll number is : %d\n",sobj.Rollno);
        //printf("Name of student : %s\n",sobj.Name);
        printf("Marks : %d\n",sobj.Marks);
    }
    
    close(fd);
}



int main()
{
	char arr[30];
	printf("Enter File Name\nInput:");
	scanf("%[^'\n']s",arr);
	FileRead(arr);
	return 0;
}
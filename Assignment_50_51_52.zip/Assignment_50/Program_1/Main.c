/*

1.Write a program which accept information of students from user and
write that information into the file.

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct student
{
	int Rollno;
	char Name[20];
	int Marks;
};

void FileWrite(char *name)
{
    int fd = 0, ret = 0, size = 0, i = 0;
    struct student sobj;
    
    fd = open(name,O_WRONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return ;
    }
    printf("Enter number of students");
    scanf("%d",&size);
    
    for(i = 1; i <= size; i++)      // while(Head!= NULL)
    {
        printf("Enter roll number\n");
        scanf("%d",&sobj.Rollno);
        printf("Enter Name of student\n");
        scanf("%s",&sobj.Name);
        printf("Enter marks\n");
        scanf("%d",&sobj.Marks);
        
        write(fd,&sobj,sizeof(sobj));   // write(fd,Head,sizeof(Node));
    }
    close(fd);
}



int main()
{
	char arr[30];
	printf("Enter File Name\nInput:");
	scanf("%[^'\n']s",arr);
	FileWrite(arr);
	return 0;
}
/*

1. Write a program which accept file name which contains information of
student and display the information of student having highest marks. 

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

struct student
{
	int Rollno;
	char Name[20];
	int Marks;
};

int FileRead(char *name1)
{
   int fd = 0, ret = 0, size = 0, i = 0;
   struct student sobj;
    
    fd = open(name1,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return -1;
    }
    
    printf("Data from file is : \n");
    int iMax = 0;
    while((ret = read(fd,&sobj,sizeof(sobj)))!= 0)
    {
        //printf("Roll number is : %d\n",sobj.Rollno);
        //printf("Name of student : %s\n",sobj.Name);
        //printf("Marks : %d\n",sobj.Marks);
		if((sobj.Marks) > iMax)
		{
			
			iMax = sobj.Marks;	
		
		}
			
	}
	
	close(fd);
	
	return iMax;
}



int main()
{
	char name1[30];
	int iRet = 0;
	printf("Enter File Name\nInput:");
	scanf("%[^'\n']s",name1);
	
	iRet = FileRead(name1);
	
	printf("\nMaximum Mark is :%d",iRet);
	
	return 0;
}
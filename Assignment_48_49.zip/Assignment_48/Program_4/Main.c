/*

4.Write application which accept file name from user and display size of file.

Input : Demo.txt

Output : File size is 56 bytes 

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

//Function to open file and read data

int DisplaySizeofFile(char fName[])
{
	int fd = 0;
	char arr[100] = {'\0'};
	int ret = 0;
	int retSum = 0;
	fd  = open(fName,O_RDONLY);
	if(fd == -1)
	{
		printf("\nUnable to open File :");
		return -1;
	}
	
	printf("Data From File is:\n");
	while((ret = read(fd,arr,100))!= 0)
	{
		retSum += ret;
		write(1,arr,ret);
	}
	
	close(fd);
	
	return retSum;
}

int main()
{
	char name[50] = {'\0'};
	int iREt = 0;
	printf("\nEnter File Name:");
	scanf("%s",name);
	iREt = DisplaySizeofFile(name);
	printf("\nSize of File is:%d",iREt);

	return 0;
}
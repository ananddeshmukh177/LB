/*

2.Write application which accept file name from user and create that file.

Input : Demo.txt

Output : File created successfully. 

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
//Application which access file name from user and display whole file on screen

//Function to open file and read data

void CreateFile(char fName[])
{
	int fd = 0;
	char arr[100] = {'\0'};
	int ret = 0;
	fd = open(fName,O_RDWR | O_CREAT,0777);//File gets created 0777 mode
	if(fd == -1)
	{
		printf("\nUnable to open File :");
	}
	else
	{
		printf("File Creation Succcess");
	}
	
	close(fd);
}

int main()
{
	char name[50] = {'\0'};
	printf("\nEnter File Name:");
	scanf("%s",name);
	CreateFile(name);
	return 0;
}
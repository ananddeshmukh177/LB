/*

1.Write application which accept file name from user and open that file in read mode.

Input : Demo.txt

Output : File opened successfully.  

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
//Application which access file name from user and display whole file on screen

//Function to open file and read data

void DisplayWholeFile(char fName[])
{
	int fd = 0;
	char arr[100] = {'\0'};
	int ret = 0;
	fd  = open(fName,O_RDONLY | O_CREAT);
	if(fd == -1)
	{
		printf("\nUnable to open File :");
		return;
	}
	
	ret = read(fd,arr,100);
	
	if(ret == -1)
	{
		printf("Unable to Open the File");
	}
	else
	{
		printf("File Open Succcess");
	}
	
	close(fd);
}

int main()
{
	char name[50] = {'\0'};
	printf("\nEnter File Name:");
	scanf("%s",name);
	DisplayWholeFile(name);
	return 0;
}
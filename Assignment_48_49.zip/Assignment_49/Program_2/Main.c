/*

1.Write a program which accepts file name from user and count number of
small characters from that file.

Input : Demo.txt

Output : Number of small characters are 23 

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

int FileRead(char *name1)
{
   int fd = 0, ret = 0, size = 0, i = 0;
   char arr[100];
    
    fd = open(name1,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return -1;
    }
    
    printf("Data from file is : \n");
    int iCnt = 0;
    while((ret = read(fd,arr,100))!= 0)
    {
		for(int i = 0; i < ret ; i++)
		{
			if(arr[i] >= 'a' && arr[i] <= 'z')
			{
				iCnt++;
			}
		}
	}
	
	close(fd);
	
	return iCnt;
}



int main()
{
	char name1[30];
	int iRet = 0;
	printf("Enter File Name\nInput:");
	scanf("%[^'\n']s",name1);
	
	iRet = FileRead(name1);
	printf("Number of Small Charcaters :%d",iRet);
	return 0;
}
/*

5.Write a program which accepts file name and one count from user and read
that number of characters from starting position.

Input : Demo.txt 12

Output : Display first 12 characters from Demo.txt 

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

void FileRead(char *name1,int iSize)
{
   int fd = 0, ret = 0, size = 0, i = 0;
   char arr[100];
    
    fd = open(name1,O_RDONLY);
    if(fd == -1)
    {
        printf("Unable to open file\n");
        return;
    }
    
	printf("Data from file is : \n");

    int iCnt = 0;
    ret = read(fd,arr,iSize);
    {
		write(1,arr,iSize);
	}
	
	close(fd);
	
}



int main()
{
	char name1[30];
	int iRet = 0;
	int iSize = 0;
	printf("Enter File Name\nInput:");
	scanf("%[^'\n']s",name1);
	
	printf("Enter A Size\nInput:");
	scanf(" %d",&iSize);
	
	FileRead(name1,iSize);
	return 0;
}
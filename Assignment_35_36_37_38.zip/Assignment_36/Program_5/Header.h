#include<stdio.h>

void StrPalindrome(char *);
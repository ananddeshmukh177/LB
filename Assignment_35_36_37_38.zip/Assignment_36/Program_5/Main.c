/*
Problem Statement: 

Accept string from user and check whether the string is palindrome
or not without considering its case.

Input : “1abccBA1”
Output : TRUE

*/
#include"Header.h"

int main()
{
	char arr[30];

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	StrPalindrome(arr);

	return 0;
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrPalindrome
//Parameters    : char *
//Return Value  : void
//Description   : it is used to check String is palindrome or not(without considering its case).
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrPalindrome(char* str)
{
	if(str == NULL)
	{
		return;
	}
	
	char * start = str;
	char * end = str;
	int len = 0;
	while(*end != '\0')
	{
		end++;
		len++;
	}
	end--;
	int iCnt = 0;
	while(start < end)
	{
		if((*start >= 'a' && *start <= 'z') || (*start >= 'A' && *start <= 'Z'))
		{
			if(*start == *end || *start+32 == *end || *start == *end+32)
			{
				iCnt++;
				//printf("iCnt =>%d\n",iCnt);
			}
		}

		start++;
		end--;

	
	}
	//printf("iCnt =>%d  \nlength =>%d",iCnt,len);

	if(iCnt == len/2)
	{
		printf("String is Palindrome");
	}
	else
	{
		printf("String is Not a Palindrome");
	}
	
	
}


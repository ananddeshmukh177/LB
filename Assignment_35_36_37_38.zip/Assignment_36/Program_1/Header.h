#include<stdio.h>//Header File 
void StrcatX(char *,char *,int);//Function Prototype/Decleration
/*
Problem Statement: 

Write a program which accepts 2 strings from user and concat N
characters of second string after first string.Value of N should be
accepted from user. (Implement strncat() function).
Note : If third parameter is greater than the size of second string then
concat whole string after first string.

Input : “Marvellous Infosystems”
		“Logic Building”
		5

Output : “Marvellous Infosystems Logic”

*/

#include"Header.h"

int main()
{
	char arr[30];
	char brr[30];
	int iCnt = 0;

	printf("Enter a First String \nInput :");
	scanf("%[^'\n']s",arr);

	printf("Enter a Second String \nInput :");
	scanf(" %[^'\n']s",brr);

	printf("Enter a Size to concat String \nInput :");
	scanf("%d",&iCnt);

	StrcatX(arr,brr,iCnt);

	printf("Concated String is: %s",arr);

	return 0;
}

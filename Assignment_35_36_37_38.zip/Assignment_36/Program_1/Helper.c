//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrcatX
//Parameters    : char *,char *,int
//Return Value  : void
//Description   : it is used to concat the string as per user given Input.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcatX(char *Src,char *Dest,int iCnt)
{
	if(Src == NULL || Dest == NULL)
	{
		return;
	}	
	while(*Src != '\0')
	{
		Src++;
	}

	*Src = ' ';
	 Src++;

	int j = 1;
	while(j <= iCnt)
	{
		*Src = *Dest;
		Src++;
		Dest++;
		j++;
	}

	*Src = '\0';
}


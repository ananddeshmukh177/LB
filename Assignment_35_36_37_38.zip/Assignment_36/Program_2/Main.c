/*
Problem Statement: 

Write a program which 2 strings from user and check whether
contents of two strings are equal or not. (Implement strcmp()
function).

Input : “Marvellous Infosystems”
		“Marvellous Infosystems”

Output : TRUE

*/

#include"Header.h"

int main()
{
	char arr[30];
	char brr[30];
	BOOL bRet = FALSE;

	printf("Enter a First String \nInput :");
	scanf("%[^'\n']s",arr);

	printf("Enter a Second String \nInput :");
	scanf(" %[^'\n']s",brr);


	bRet = StrcmpX(arr,brr);

	if(bRet == TRUE)
	{
		printf("Strings Are Same");
	}
	else
	{
		printf("Strings Are Not Same");
	}

	return 0;
}

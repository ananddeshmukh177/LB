#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrcmpX
//Parameters    : char *,char *
//Return Value  : BOOL
//Description   : it is used to compare to strings.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL StrcmpX(char *Src,char *Dest)
{
	if(Src == NULL || Dest == NULL)
	{
		return;
	}	
	while(*Src != '\0')
	{
		if(*Src != *Dest)
		{
			break;
		}
		Src++;
		Dest++;
	}

	if(*Src == '\0')
	{
		return TRUE;
	}

	return FALSE; 
}


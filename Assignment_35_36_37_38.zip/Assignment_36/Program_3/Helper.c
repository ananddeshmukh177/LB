#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrNcmpX
//Parameters    : char *,char *,int
//Return Value  : BOOL
//Description   : it is used to check first N contents are same or not.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL StrNcmpX(char *Src,char *Dest,int iCnt)
{

	if(Src == NULL || Dest == NULL)
	{
		return;
	}	
    int iCounter = 0;
	while(iCnt != 0)
	{
		if(*Src == *Dest)
		{
			iCounter++;
		}
		Src++;
		Dest++;
		iCnt--;
	}

	if(iCounter > 0)
	{
		return TRUE;
	}

	return FALSE; 
}

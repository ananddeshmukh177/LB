#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrRevToggleX
//Parameters    : char *
//Return Value  : void
//Description   : it is used to reverse and toggle.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrRevToggleX(char *Str)
{

	if(Str == NULL)
	{
		return;
	}	
    
	char* start = Str;
	char* end = Str;
	char cTemp = '\0';
	while(*end != '\0')
	{
		end++;
	}
	end--;
	while(start <= end)
	{
		if(*start >= 'a' && *start <= 'z')
		{
			*start = *start-32;
		}
		else
		{
			*start = *start+32;
		}

		if(*end >= 'a' && *end <= 'z')
		{
			*end = *end-32;
		}
		else
		{
			*end = *end+32;
		}
		
		if(start == end)
		{
			if(*start >= 'a' && *start <= 'z')
			{
				*start = *start-32;
			}
			else
			{
				*start = *start+32;
			}
		}
		cTemp = *start;
		*start = *end;
		*end = cTemp;
		start++;
		end--;
		
	}
}

/*
Problem Statement: 

Accept sing from user and reverse the contents of that string by
toggling the case.

Input : “aCBdef”
Output : “FEDcbA”

*/

#include"Header.h"

int main()
{
	char arr[30];
	BOOL bRet = FALSE;

	printf("Enter a First String \nInput :");
	scanf("%[^'\n']s",arr);

	StrRevToggleX(arr);

	printf("Reverse Toggle String :%s",arr);

	return 0;
}

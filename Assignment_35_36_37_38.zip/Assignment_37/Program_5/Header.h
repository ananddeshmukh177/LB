#include<stdio.h>//Header File 
#include<String.h>
void StrCapitalX(char *);//Function Prototype/Decleration
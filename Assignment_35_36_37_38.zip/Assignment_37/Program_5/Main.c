/*
Problem Statement: 

Write a program which accept string from user and replace each
occurrence of first character of each word into capital case.

Input : “marvellous infosystems by Piyush khairnar”
Output : “Marvellous Infosystems By Piyush Khairnar”

*/

#include"Header.h"

int main()
{
	char arr[40];

	printf("Enter a First String \nInput :");
	scanf("%[^'\n']s",arr);
	
	StrCapitalX(arr);

	printf("String with Capital Case: %s",arr);

	return 0;
}

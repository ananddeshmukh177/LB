#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrCapitalX
//Parameters    : char *
//Return Value  : void
//Description   : it is used to count largest word length in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrCapitalX(char *Src)
{
	if(Src == NULL)
	{
		return;
	}	
	char *Dest = Src;
	int i = 0;
	while(*Src != '\0')
	{
		if(*Src == ' ')
		{
			*Dest = *Src;
			Src++;
			Dest++;
			i = 0;

		}

		if(i == 0)
		{	
			if(*Src >= 'A' && *Src <= 'Z')
			{
			*Dest = *Src;
			Src++;
			Dest++;
			}
			else
			{
				*Dest = *Src-32;
				Src++;
				Dest++;
			}	
			i++;
		}
		else
		{
			*Dest = *Src;
			Src++;
			Dest++;
			i++;
		}
		
	}
	
	*Dest = '\0';
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : StrCpyX
//Parameters    : char *,char*
//Return Value  : void
//Description   : it is used to copy string into another removing extra white spaces 
//                in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrCpyX(char *Src,char *Dest)
{
	//String S1 = "";
	if(Src == NULL || Dest == NULL)
	{
		return;
	}	
	while(*Src != '\0')
	{
		if(*Src == ' ')
		{
			while(*Src == ' ')
				{
					Src++;
				}
		
		*Dest = ' ';
		Dest++;
		}
		
		else
		{
			
			*Dest = *Src;
			Src++;
			Dest++;
		}
		
		
	}
	
	*Dest = '\0';
}
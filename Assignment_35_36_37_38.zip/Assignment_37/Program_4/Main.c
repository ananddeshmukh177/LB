/*
Problem Statement: 

Write a program which accept string from user and copy the
contents into another string by removing extra white spaces.

Input : “Marvellous   multi   OS”
Output : “Marvellous multi OS”

*/

#include"Header.h"

int main()
{
	char arr[40];
	char brr[40];

	printf("Enter a First String \nInput :");
	scanf("%[^'\n']s",arr);
	
	StrCpyX(arr,brr);

	printf("Copied String Without Extra White Spaces: %s",brr);

	return 0;
}

#include<stdio.h>//Header File 
#include<String.h>
void StrCpyX(char *,char *);//Function Prototype/Decleration
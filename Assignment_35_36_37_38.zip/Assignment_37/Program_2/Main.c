/*
Problem Statement: 

Write a program which accept string from user and return length of
largest word.

Input : “Marvellous Multi OS Infosystems”
Output : 11

*/

#include"Header.h"

int main()
{
	char arr[40];
	int iRet = 0;

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	iRet = LargestWordLength(arr);

	printf("Number of Words are: %d",iRet);

	return 0;
}

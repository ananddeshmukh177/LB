#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : LargestWordLength
//Parameters    : char *
//Return Value  : int
//Description   : it is used to count largest word length in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int LargestWordLength(char *Str)
{
	int iCnt = 0;
	int iMax = 0;
    
	if(Str == NULL)
	{
		return -1;
	}	
	while(*Str != '\0')
	{
		iCnt = 0;
		printf("In Side First While :*str: %d",*Str);
		if(*Str == ' ')
		{
			while(*Str == ' ')
			{
				Str++;
			}
		}

		while(*Str != ' ')
		{
		printf("In Side Side First While :*str: %d\n",*Str);

			if((*Str >= 'a' && *Str <= 'z') || (*Str >= 'A' && *Str <= 'Z') || (*Str >= '0' && *Str <= '9'))
				{
						Str++;
						iCnt++;
				}
			else{
						break;
				}
		}
		
		printf("Counter : %d\n",iCnt);

		if(*Str == ' ')
		{
			while(*Str == ' ')
			{
				Str++;
			}
		}

		if(iMax < iCnt)
		{
			iMax = iCnt;
		}

	}

	return iMax;

}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : ReverseWordInPlace
//Parameters    : char *
//Return Value  : void
//Description   : it is used to reverse word in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void ReverseWordInPlace(char *Str)
{
    char* arr = Str;
	char* brr = Str;

	int len = 0;
	int k = 0;
	int i = 0;
	
	if(Str == NULL)
	{
		return;
	}	
	
	while(Str[i] != '\0')
	{
		i++;
	}
	
	len = i-1;
	int	len1 = len;

	while(len >= 0)
	{
		*brr=Str[len];
		brr++;
		len--;
	}
	
	*brr='\0';
	
	int v= 0;
	while(len1 >= 0)
	{
			while(brr[len1] != ' ')
			{
				arr[v] = brr[len1];
				v++;
				len1--;
				
			}
			arr[v]=' ';
			v++;
			len1--;

	}
	
	arr[v]='\0';
	
	
	
	
	
}
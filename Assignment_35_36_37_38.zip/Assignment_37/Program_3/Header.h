#include<stdio.h>//Header File 
void ReverseWordInPlace(char *);//Function Prototype/Decleration
/*
Problem Statement: 

Write a program which accept string from user and reverse each
word in place.

Input : “Marvellous Multi OS”
Output : “suollevraM itluM SO”

*/

#include"Header.h"

int main()
{
	char arr[40];

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	ReverseWordInPlace(arr);

	printf("Reverse Word in a String is :%s",arr);

	return 0;
}

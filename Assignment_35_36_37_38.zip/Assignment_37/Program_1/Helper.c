#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : countWords
//Parameters    : char *
//Return Value  : int
//Description   : it is used to count number of words in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int countWords(char *Str)
{
	int iCnt = 0;
	if(Str == NULL)
	{
		return -1;
	}	
	for(int i = 0; Str[i]!='\0' ;i++)
	{
		if(Str[i] == ' ' && Str[i+1] != ' ')
		{
			iCnt++;
		}
	}

	return iCnt+1;

}
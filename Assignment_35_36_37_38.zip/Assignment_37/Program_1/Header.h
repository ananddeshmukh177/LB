#include<stdio.h>//Header File 

int countWords(char *);//Function Prototype/Decleration
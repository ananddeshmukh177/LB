/*
Problem Statement: 

Write a program which accept string from user count number of
words from string

Input : “Marvellous Multi OS”
Output : 3

Input : “ Marvellous Multi OS Pune”
Output : 4

*/

#include"Header.h"

int main()
{
	char arr[40];
	int iRet = 0;

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	iRet = countWords(arr);

	printf("Number of Words are: %d",iRet);

	return 0;
}

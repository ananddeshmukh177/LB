#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to Check 9th and 12th Bits are on or off.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/*
--------------------------------------------------------------------------
Test Case : 

--------------------------------------------------------------------------
*/
BOOL ChkBit(UINT iNo)
{	
	int iRem = 0;
	int iPos = 0;
	while(iNo != 0)
	{
		iPos++;
		iRem = iNo%2;
		if(iPos == 9 || iPos == 12)
		{
			break;
		}
		
		iNo = iNo/2;
		
	}
	
	if((iPos == 9 || iPos == 12) && (iRem == 1))
	{
		return TRUE;
	}
	
	
	return FALSE;
}

#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ToggleBitRange
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to Toggle Bit Range.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/*
--------------------------------------------------------------------------
Test Case : 

--------------------------------------------------------------------------
*/
UINT ToggleBitRange(UINT iNo,UINT iStart,UINT iEnd)
{	
	int iRem = 0;
	int iPos = 0;
    UINT iMask = 0X00000001;


	for(int i = iStart ; i <= iEnd ; i++)
	{
		iMask = iMask << (i-1);
		iNo = iNo ^ iMask;
		iMask = 0X00000001;
	}
	return iNo;
}

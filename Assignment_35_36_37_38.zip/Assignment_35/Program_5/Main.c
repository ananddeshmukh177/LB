/*
Problem Statement: 

Write a program which accept one number from user and range of
positions from user. Toggle all bits from that range.

Input : 897 9 13
Toggle all bits from position 9 to 13 of input number ie 879.

*/

#include"Header.h"


int main()
{
	UINT iValue1 = 0;
	UINT rangeStart = 0;
	UINT rangeEnd = 0;
	UINT iRet = 0;
	
	printf("Please Enter a First Number\nInput :");
	scanf("%d",&iValue1);
	
	printf("Please Enter a Ranges First Position\nInput :");
	scanf("%d",&rangeStart);
	
	printf("Please Enter a Ranges Last Position\nInput :");
	scanf("%d",&rangeEnd);

	
	iRet = ToggleBitRange(iValue1,rangeStart,rangeEnd);
	
	printf("Number after toggle is :%d",iRet);

	return 0;
}
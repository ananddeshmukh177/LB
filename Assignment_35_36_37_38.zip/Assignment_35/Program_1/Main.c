/*
Problem Statement: 

Write a program which accept one number from user and count number of
ON (1) bits in it without using % and / operator.

Input : 11
Output : 3 

*/

#include"Header.h"


int main()
{
	UINT iValue = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	iRet = CountOne(iValue);
	
	printf("ON Bit Count is:%d",iRet);
	

	return 0;
}
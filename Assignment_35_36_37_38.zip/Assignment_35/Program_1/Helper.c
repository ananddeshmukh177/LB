#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CountOne
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to count number of
//                ON (1) bits in it without using % and / operator.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

UINT CountOne(UINT iNo)
{	
	UINT iCnt = 0;
	//int iRem = 0;
	
	while(iNo != 0)
	{
			if((iNo & 1) == 1)
			{				
				iCnt++;
			}
			iNo = iNo >> 1;

	}
	
	return iCnt;

	/*while(iNo != 0)
	{
		iRem = iNo%2;
		iPP++;
		if(iPP == iPos)
		{
			break;
		}
		iNo = iNo/2;
	}
	
	if((iPos == iPP) && (iRem == 1))
	{
		return TRUE;
	}*/
	
	
}

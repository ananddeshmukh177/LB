#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CommonBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to count number of Common Bit.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/*
--------------------------------------------------------------------------
Test Case : 

		Input : 10 15
		Binary: 0000 0000 0000 0000 0000 0000 0000 1010
				0000 0000 0000 0000 0000 0000 0000 1111 &
				-----------------------------------------
				0000 0000 0000 0000 0000 0000 0000 1010
				
--------------------------------------------------------------------------
*/
UINT CommonBit(UINT iNo1,UINT iNo2)
{	
	UINT iResult = 0;
	UINT iCnt = 0;
	UINT iRem = 0;
	UINT iMask1 = 0X00000000;
	UINT iMask2 = 0X00000000;
	
	iNo1 = iMask1 ^ iNo1;
	iNo2 = iMask2 ^ iNo2;
	iResult = (iNo1 & iNo2);
	
	while(iResult != 0)
	{
	    iRem = iResult%2;
		if(iRem==1)
		{
			iCnt++;
		}
		iResult = iResult/2;

	}
	
	return iCnt;
}

/*
Problem Statement: 

Write a program which accept two numbers from user and display position
of common ON bits from that two numbers.

Input : 10 15 (1010 1111)
Output : 2 4 

*/

#include"Header.h"


int main()
{
	UINT iValue1 = 0;
	UINT iValue2 = 0;
	UINT iRet = 0;
	
	printf("Please Enter a First Number\nInput :");
	scanf("%d",&iValue1);

	printf("Please Enter a Second Number\nInput :");
	scanf("%d",&iValue2);
	
	iRet = CommonBit(iValue1,iValue2);
	
	printf("Number of common bits are:%d",iRet);
	

	return 0;
}
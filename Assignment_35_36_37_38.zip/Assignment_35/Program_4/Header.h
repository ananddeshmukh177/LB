#include<stdio.h>     //Header File 

typedef int BOOL;
typedef unsigned int UINT; 

#define TRUE 1
#define FALSE 0 

BOOL ChkBit(UINT,UINT,UINT);  //Function Prototype/Decleration
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to Check any one Bit is on or off.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/*
--------------------------------------------------------------------------
Test Case : 

--------------------------------------------------------------------------
*/
BOOL ChkBit(UINT iNo,UINT iPos1,UINT iPos2)
{	
	int iRem = 0;
	int iPos = 0;
	while(iNo != 0)
	{
		iPos++;
		iRem = iNo%2;
		if(iPos == iPos1 || iPos == iPos2)
		{
			break;
		}
		
		iNo = iNo/2;
		
	}
	
	if((iPos == iPos1 || iPos == iPos2) && (iRem == 1))
	{
		return TRUE;
	}
	
	
	return FALSE;
}

/*
Problem Statement: 

Write a program which accept one number , two positions from user and
check whether bit at first or bit at second position is ON or OFF.

Input : 10 3 7
Output : TRUE 

*/

#include"Header.h"


int main()
{
	UINT iValue1 = 0;
	UINT iPos1 = 0;
	UINT iPos2 = 0;
	BOOL bRet = FALSE;
	
	printf("Please Enter a First Number\nInput :");
	scanf("%d",&iValue1);
	
	printf("Please Enter a First Position\nInput :");
	scanf("%d",&iPos1);
	
	printf("Please Enter a Second Position\nInput :");
	scanf("%d",&iPos2);

	
	bRet = ChkBit(iValue1,iPos1,iPos2);
	
	if(bRet == TRUE)
	{
		printf("Bits are ON");
	}
	else
	{
		printf("ANy One or Both Bits are OFF");

	}
	

	return 0;
}
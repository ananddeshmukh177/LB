#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Function Name : Pattern
//Parameters    : char *
//Return Value  : void
//Description   : it is used to print the pattern.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void Pattern(char *Str)
{
	char *arr = Str;
	if(Str == NULL)
	{
		return;
	}	
	int len = 0;
	while(*Str != '\0')
	{
		Str++;
		len++;
	}
	for(int  i=0 ; i<=len-1 ;i++)
	{
		for(int  i=0 ; i<=len-1 ;i++)
		{
			printf("%c\t",arr[i]);
		}
		printf("\n");
	}
}
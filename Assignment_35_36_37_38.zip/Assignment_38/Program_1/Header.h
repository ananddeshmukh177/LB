#include<stdio.h>//Header File 

void Pattern(char *);//Function Prototype/Decleration
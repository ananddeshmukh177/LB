/*
Problem Statement: 

Write a program which accept string from user and print below
pattern.

Input : “Marvellous”
Output : M
		 M a
		 M a r
		 M a r v
		 M a r v e
		 M a r v e l
		 M a r v e l l	
		 M a r v e l l o
		 M a r v e l l o u
		 M a r v e l l o u s
		 
Input : “PPA”
Output : P
		 P P
		 P P A
*/

#include"Header.h"

int main()
{
	char arr[40];

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	Pattern(arr);

	return 0;
}

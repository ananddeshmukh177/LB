/*
Problem Statement: 

Write a program which accept string from user and print below
pattern.
Input : “Marvellous”
Output :    m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s
			m a r v e l l o u s

*/

#include"Header.h"

int main()
{
	char arr[40];

	printf("Enter a String \nInput :");
	scanf("%[^'\n']s",arr);

	Pattern(arr);

	return 0;
}

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      OddDisplay
// Parameters    :      int
// Return value  :      void
// Description   :      print odd numbers up to N.
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void OddDisplay(int iNo) //Method Implementation;
{
	int iCnt = 0;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= iNo ; iCnt++)
	{
		if((iCnt % 2) != 0)
		{
			printf("%d ",iCnt);
		}
	}
}
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Pattern
// Parameters    :      int
// Return value  :      void
// Description   :      Display Pattern
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void Pattern(int iNo) //Method Implementation;
{
	int iCnt = 0;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= iNo ; iCnt++)
	{
		printf("$ * ");
	}
}
/*
    Problem statement :   Write a program which accept N and print first 5 multiples of N.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	
			
	printf("Enter  Numbers:"); //Display Statement
	scanf("%d",&iValue1);      //Accept input
	MultipleDisplay(iValue1);          //Function Call
	return 0;                  //Successful Termination
}
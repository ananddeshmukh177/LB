#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      MultipleDisplay
// Parameters    :      int
// Return value  :      void
// Description   :      Used to dispaly first 5 Multiple of N
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void MultipleDisplay(int iNo) //Method Implementation;
{
	int iCnt = 0;
	int iCounter = 0;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= 5 ; iCnt++)
	{
		printf("%d ",iCnt*iNo);
	}
}
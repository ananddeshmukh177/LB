#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      int
// Return value  :      void
// Description   :      print numbers till that user given number.
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void Display(int iNo) //Method Implementation;
{
	int iCnt = 0;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= iNo ; iCnt++)
	{
		printf("%d ",iCnt);
	}
}
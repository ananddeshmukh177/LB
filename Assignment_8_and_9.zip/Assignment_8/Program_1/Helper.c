#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Number
// Parameters    :      int
// Return value  :      void
// Description   :      it Display Small Medium Large Number
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void Number(int iNo) //Method Implementation;
{
	if(iNo <  50)
	{
		printf("Small");
	}
	else if(iNo >=  50 && iNo <= 100)
	{
		printf("Medium");
	}
	else
	{
		printf("Large");
	}
}
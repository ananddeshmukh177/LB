/*
    Problem statement : Write a program which accept number from user and if number is less than 50
    then print small , if it is greater than 50 and less than 100 then print medium, if it is
    greater than 100 then print large.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
			
	printf("Enter  Numbers:"); //Display Statement
	scanf("%d",&iValue1);      //Accept input
	Number(iValue1);     //Function Call
	
	return 0;                  //Successful Termination
}
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Factorial
// Parameters    :      int
// Return value  :      int
// Description   :      Accept single digit number from user and print Fctorial.
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

int Factorial(int iNo) //Method Implementation;
{
	int iCnt = 0;
	int fact = 1;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1;iCnt <= iNo; iCnt++)
	{
		fact = fact*iCnt;
	}
	return fact;
}
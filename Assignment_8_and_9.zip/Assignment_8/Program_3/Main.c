/*
    Problem statement :  Write a program to find factorial of given number
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iRet = 0;
	
			
	printf("Enter  Numbers:"); //Display Statement
	scanf("%d",&iValue1);      //Accept input
	iRet = Factorial(iValue1);          //Function Call
	printf("Factorial of given Number is: %d",iRet);
	return 0;                  //Successful Termination
}
#include<stdio.h>

void Table(int);
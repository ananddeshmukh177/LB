#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      TableRev
// Parameters    :      int
// Return value  :      void
// Description   :      Display Reverse Table
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void TableRev(int iNo) //Method Implementation;
{
	int iCnt = 0;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 10 ; iCnt >= 1 ; iCnt--)
	{
		printf("%d ",iNo*iCnt);
	}
}
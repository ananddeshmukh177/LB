#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      int
// Return value  :      void
// Description   :      Accept single digit number from user and print it into word.
// Author        :      Anand Manchakrao Deshmukh
// Date          :      06 August 2020
//
//////////////////////////////////////////////////////////////

void Display(int iNo) //Method Implementation;
{
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	switch(iNo)
	{
		case 0: printf("Zero");
		break;
		
		case 1: printf("One");
		break;
		
		case 2: printf("Two");
	    break;
		
		case 3: printf("Three");
		break;
		
		case 4: printf("Four");
	    break;
		
		case 5: printf("Five");
	    break;
		
		case 6: printf("Six");
		break;
		
		case 7: printf("Seven");
        break;
		
		case 8: printf("Eight");
		break;
		
		case 9: printf("Eight");
		break;
		
		default : printf("Invalid Number");
	
	}
}
/*
2.Write a recursive program which accept number from user and return
summation of its digits.

Input : 879

Output : 24 
*/
#include<stdio.h>
#include<stdlib.h>

int Display(int iNo)
{
	static int iRem = 0;
	static int iSum = 0;
	
	if(iNo > 0)
	{
		iRem = iNo%10;
		iSum += iRem;
		iNo = iNo/10;
		Display(iNo);
	}
	return iSum;
}

int main()
{
	int iNo = 0;
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iSum = Display(iNo);
	printf("Output:%d",iSum);
	return 0;
}
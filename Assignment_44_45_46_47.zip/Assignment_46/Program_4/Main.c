/*
4.Write a recursive program which accept number from user and return its
factorial.

Input : 5

Output : 120 
*/
#include<stdio.h>
#include<stdlib.h>

int Factorial(int iNo)
{
	static int iSum = 1;
	if(iNo > 0)
	{
		iSum *= iNo;
		Factorial(iNo-1);
	}
	return iSum;
}

int main()
{
	int iNo = 0;
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iSum = Factorial(iNo);
	printf("Output:%d",iSum);
	return 0;
}
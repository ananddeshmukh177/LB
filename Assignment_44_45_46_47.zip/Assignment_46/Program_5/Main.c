/*
5. Write a recursive program which accept number from user and return its
product of digits.

Input : 523

Output : 30 
*/
#include<stdio.h>
#include<stdlib.h>

int Product(int iNo)
{
	static int iSum = 1;
	static int iRem = 0;
	if(iNo > 0)
	{
		iRem = iNo%10;
		iSum *= iRem;
		iNo = iNo/10;
		Product(iNo);
	}
	return iSum;
}

int main()
{
	int iNo = 0;
	int iProduct = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iProduct = Product(iNo);
	printf("Output:%d",iProduct);
	return 0;
}
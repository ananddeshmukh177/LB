/*
4.Write a recursive program which display below pattern.
Input : 6
Output : A B C D E F 
*/
#include<stdio.h>
#include<stdlib.h>

void Display(int iNo)
{
	static char ch = 'A';
	if(iNo > 0)
	{
		printf("%c\t",ch);
		ch += 1;
		iNo--;
		Display(iNo);
	}
}

int main()
{
	int iNo = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	Display(iNo);
	return 0;
}
/*
1. Write a recursive program which display below pattern.
Input : 5
Output : * * * * * 
*/
#include<stdio.h>
#include<stdlib.h>

void Display(int iNo)
{
	if(iNo > 0)
	{
		printf("*\t");
		iNo--;
		Display(iNo);
	}
}

int main()
{
	int iNo = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	Display(iNo);
	return 0;
}
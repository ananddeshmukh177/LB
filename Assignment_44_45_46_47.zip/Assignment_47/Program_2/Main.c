/*

2. Write a recursive program which accept number from user and return
largest digit

Input : 87983

Output : 9 

*/

#include<stdio.h>
#include<stdlib.h>

int Max(int iNo)
{
	static int iMax = 0;
	static int iRem = 0;
	if(iNo > 0)
	{
		iRem = iNo%10;
		if(iRem > iMax)
		{
			iMax = iRem;
		}
		iNo = iNo/10;
		Max(iNo);
	}
	return iMax;
}

int main()
{
	int iNo = 0;
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iSum = Max(iNo);
	printf("Max Digit: %d",iSum);
	return 0;
}
/*

5. Write a recursive program which accept number from user and return its
reverse number.

Input : 523

Output : 325 

*/

#include<stdio.h>
#include<stdlib.h>

int Reverse(int iNo)
{
	static int iRem = 0;
	static int iRev = 0;
	if(iNo > 0)
	{
		iRem = iNo%10;
		iRev = iRev*10+iRem;
		iNo = iNo/10;
		Reverse(iNo);
	}
	return iRev;
}

int main()
{
	int iNo = 0;
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iSum = Reverse(iNo);
	printf("Reverse Number: %d",iSum);
	return 0;
}
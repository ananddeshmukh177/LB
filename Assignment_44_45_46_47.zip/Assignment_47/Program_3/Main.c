/*

3.Write a recursive program which accept string from user and count number
of small characters.

Input : HElloWOrlD

Output : 5 

*/

#include<stdio.h>
#include<stdlib.h>

int CountSmall(char* Str)
{
	static int iCnt = 0;
	if(*Str != '\0')
	{
		if((*Str >= 'a') && (*Str <= 'z'))
		{
			iCnt++;
		}
		Str++;
		CountSmall(Str);
	}
	return iCnt;
}

int main()
{
	char arr[20];
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%[^'\n']s",arr);
	iSum = CountSmall(arr);
	printf("Number of Small Characters: %d",iSum);
	return 0;
}
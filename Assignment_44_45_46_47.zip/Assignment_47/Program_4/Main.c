/*

4.Write a recursive program which accept number from user and return
smallest digit

Input : 87983

Output : 3  

*/

#include<stdio.h>
#include<stdlib.h>

int Min(int iNo)
{
	static int iMin = 9999;
	static int iRem = 0;
	if(iNo > 0)
	{
		iRem = iNo%10;
		if(iRem < iMin)
		{
			iMin = iRem;
		}
		iNo = iNo/10;
		Min(iNo);
	}
	return iMin;
}

int main()
{
	int iNo = 0;
	int iSum = 0;
	printf("Enter a Number\nInput:");
	scanf("%d",&iNo);
	iSum = Min(iNo);
	printf("Min Digit: %d",iSum);
	return 0;
}
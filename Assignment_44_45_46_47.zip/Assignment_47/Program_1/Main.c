/*

1.Write a recursive program which accept string from user and count white spaces.

Input : HE llo WOr lD

Output : 3  

*/

#include<stdio.h>
#include<stdlib.h>

int CountSpaces(char* Str)
{
	static int iCnt = 0;
	if(*Str != '\0')
	{
		if(*Str == ' ')
		{
			iCnt++;
		}
		Str++;
		CountSpaces(Str);
	}
	return iCnt;
}

int main()
{
	char arr[30];
	int iSum = 0;
	printf("Enter a String\nInput:");
	scanf("%[^'\n']s",arr);
	iSum = CountSpaces(arr);
	printf("Number of White Spaces: %d",iSum);
	return 0;
}
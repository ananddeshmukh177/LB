/*

1.Write a program which reverse each element of singly linked list.

Function Prototype : void InsertFirst(PPNODE,int);

void Reverse( PNODE Head);

Input linked list : |11|->|28|->|17|->|41|->|6|->|89|

Output : |11|->|82|->|71|->|14|->|6|->|98| 

*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name     : Reverse
// Description       : Used to Reverse each data element of Linked List
// Parameters        : Addreass of First pointer & data of node
// Return Value      : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

void  Reverse(PNODE Head)
{
	int iRev = 0;
	int iRem = 0;
	int No = 0;
	printf("Reverse Numbers are :\n");
	while(Head != NULL)
	{
		No = Head->data;
		iRev = 0;
		while(No != 0)
		{
			iRem = No%10;
			iRev = iRev*10+iRem;
			No = No/10;
		}
		printf("%d\t",iRev);
		
		Head = Head->next;
	}
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;

 InsertFirst(&First, 101);
 InsertFirst(&First, 51);
 InsertFirst(&First, 21);
 InsertFirst(&First, 11);
 InsertFirst(&First, 28);
 InsertFirst(&First, 6);

 
 Reverse(First);

 return 0;
} 
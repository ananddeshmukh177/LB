#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      DisplayNonFactors
// Parameters    :      int
// Return value  :      void
// Description   :      it diplsay non-factors number only.
// Author        :      Anand Manchakrao Deshmukh
// Date          :      31 July 2020
//
//////////////////////////////////////////////////////////////

void DisplayNonFactors(int iNo) //Method Implementation;
{
	int iCnt = 0;
	//Filter
	if(iNo == 0)
	{
		printf("0");
	}
	
	//INPUT UPDATOR
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iNo == 1)
	{
		printf("1");
	}
	
	

	//      1             2           3
	for(iCnt = 2 ; iCnt < iNo ; iCnt++)
	{
		//       4
		if(iNo % iCnt != 0)
		{
			printf("%d ",iCnt);
		}
		
	}
	
}
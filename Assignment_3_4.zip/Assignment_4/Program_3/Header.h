
#include<stdio.h>     //Include standard io library

void DisplayNonFactors(int); //Method Prototype
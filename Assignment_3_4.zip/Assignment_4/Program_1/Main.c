/*
    Problem statement : Write a program which accept one number from user and diplsay multiplication of factors.
*/

/*
    Algorith :
 
    START
            Accept number from user and store into the variable no
              
            Craete one counter as cnt and initialise to 1
			
			also declare multi variable
 
            Iterate till the counter is less than the number ie no
                check whether the cnt divides the no completetly
                    if yes
                        then check cnt multiply every time with multi
						      
            continue to the iteration
			
			return multi variable
    END
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue = 0;
	int iAns = 0;	//Local Variable
		
	printf("Enter a Number:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	iAns = MultiOfFactors(iValue);          //Function Call
	
	printf("Multiplication of Factors :%d",iAns);
		
	return 0;                 //Successful Termination
}
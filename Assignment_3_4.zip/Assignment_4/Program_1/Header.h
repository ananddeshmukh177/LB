
#include<stdio.h>     //Include standard io library

int MultiOfFactors(int); //Method Prototype
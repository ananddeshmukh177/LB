#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      MultiOfFactors
// Parameters    :      int
// Return value  :      int
// Description   :      it gives multiplication of factors
// Author        :      Anand Manchakrao Deshmukh
// Date          :      31 July 2020
//
//////////////////////////////////////////////////////////////

int MultiOfFactors(int iNo) //Method Implementation;
{
	int iCnt = 0;
	int iMulti = 1;
	//FILTER
	if(iNo == 0)
	{
		return 0;
	}
	//INPUT UPDATOR
	if(iNo < 0)
	{
		iNo = -iNo;
	}

	//      1             2           3
	for(iCnt = 2 ; iCnt <= iNo/2 ; iCnt++)
	{
		//       4
		if(iNo % iCnt == 0)
		{
			iMulti=iMulti*iCnt;
		}
		
	}
	return iMulti;
}
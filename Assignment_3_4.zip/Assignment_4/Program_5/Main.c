/*
    Problem statement : Write a program which accept number from user and return difference between
                        summation of all its factors and non factors
*/

/*
    Algorith :
 
    START
            Accept number from user and store into the variable no
 
			declare sumf of factors and sumnf of non-factors
			
            Craete one counter as cnt and initialise to 1
 
            Iterate till the counter is less than the number ie no
                check whether the cnt divides the no completetly
                    if yes
                        then sum of factors into sumf
				    otherwise
					    then sum of non-factors into sumnf
                incremnet the value of counter by 1
 
            continue to the iteration
			
			return sumf-sumnf
			
			
    END
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue = 0;
	int iAns = 0;	//Local Variable
		
	printf("Enter a Number:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	iAns = FactDiff(iValue);          //Function Call
	
	printf("Difference between factors and Non-Factors is :%d",iAns);
		
	return 0;                 //Successful Termination
}
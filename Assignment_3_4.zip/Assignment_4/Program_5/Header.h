
#include<stdio.h>     //Include standard io library

int FactDiff(int); //Method Prototype
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      FactDiff
// Parameters    :      int
// Return value  :      int
// Description   :      calculate factors and non-factors difference
// Author        :      Anand Manchakrao Deshmukh
// Date          :      31 July 2020
//
//////////////////////////////////////////////////////////////

int FactDiff(int iNo) //Method Implementation;
{
	int iCnt = 0;
	int iSum1 = 0;
	int iSum2 = 0;

	//FILTER
	if(iNo == 0)
	{
		return 0;
	}
	//INPUT UPDATOR
	if(iNo < 0)
	{
		iNo = -iNo;
	}

	//      1             2           3
	for(iCnt = 1 ; iCnt < iNo ; iCnt++)
	{
		//Factor
		if(iNo % iCnt == 0)
		{
			iSum1=iSum1+iCnt;
		}                              //4
		//Non-Factor       
		if(iNo % iCnt != 0)
		{
			iSum2=iSum2+iCnt;
		}
		
	}
	return iSum1-iSum2;
}
/*
    Problem statement : Write a program which accept one number from user and diplsay factors in decreasing order.
*/
/*
    Algorith :
 
    START
            Accept number from user and store into the variable no
 
            Craete one counter as cnt and initialise to 1
 
            Iterate till the counter is less than the number ie no in reverse order
                check whether the cnt divides the no completetly
                    if yes
                        then display cnt
 
            continue to the iteration
    END
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue = 0;
	int iAns = 0;	//Local Variable
		
	printf("Enter a Number:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	DecFactors(iValue);          //Function Call
			
	return 0;                 //Successful Termination
}
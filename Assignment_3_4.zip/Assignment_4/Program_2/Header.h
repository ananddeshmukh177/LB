
#include<stdio.h>     //Include standard io library

void DecFactors(int); //Method Prototype
/*
    Problem statement : Write a program which accept number from user and return summation of all its
                        non factors.
*/

/*
    Algorith :
 
    START
            Accept number from user and store into the variable no
 
			declare one summ variable
			
            Craete one counter as cnt and initialise to 1
 
            Iterate till the counter is less than the number ie no
                check whether the cnt "NOT" divides the no completetly
                    if yes
                        then add number with summ
		    incremnet the value of counter by 1
 
            continue to the iteration
			
			return summ
    END
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue = 0;
	int iAns = 0;	//Local Variable
		
	printf("Enter a Number:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	iAns = SumOfFactors(iValue);          //Function Call
	
	printf("Addition of Non-Factors :%d",iAns);
		
	return 0;                 //Successful Termination
}
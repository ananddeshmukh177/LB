
#include<stdio.h>     //Include standard io library

int SumOfFactors(int); //Method Prototype
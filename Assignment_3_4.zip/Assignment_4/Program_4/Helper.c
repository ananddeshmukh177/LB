#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      SumOfFactors
// Parameters    :      int
// Return value  :      int
// Description   :      it gives Addition of factors
// Author        :      Anand Manchakrao Deshmukh
// Date          :      31 July 2020
//
//////////////////////////////////////////////////////////////

int SumOfFactors(int iNo) //Method Implementation;
{
	int iCnt = 0;
	int iSum = 0;
	//FILTER
	if(iNo == 0)
	{
		return 0;
	}
	//INPUT UPDATOR
	if(iNo < 0)
	{
		iNo = -iNo;
	}

	//      1             2           3
	for(iCnt = 1 ; iCnt < iNo ; iCnt++)
	{
		//       4
		if(iNo % iCnt != 0)
		{
			iSum=iSum+iCnt;
		}
		
	}
	return iSum;
}
#include "Header.h"

//////////////////////////////////////////////////////////////
//
//  Function name : CheckVowel
//  Input : Char
//  Output :    BOOLEAN
//  Description :   It is used to check vowel
//  Autor : Anand Manchakrao Deshmukh
//  Date :  31th July 2020
//
//////////////////////////////////////////////////////////////

BOOLEAN CheckVowel(char cChar)
{
	//char cAns='\0';

	if(((cChar == 'a') || (cChar == 'e') || (cChar == 'i') || (cChar == 'o') || (cChar == 'u') ) 
       ||((cChar == 'A') || (cChar == 'E') || (cChar == 'I') || (cChar == 'O') || (cChar == 'U')))
		{
			return TRUE;
		}
	else
		{
			return FALSE;
		}
}



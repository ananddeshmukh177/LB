
#include<stdio.h>       // REquired for printf and scanf

typedef int BOOLEAN;

#define TRUE 1
#define FALSE 0

BOOLEAN CheckVowel(char);

/*
Problem statement : Accept on character from user and check whether that character is vowel
(a,e,i,o,u) or not.
*/

/*
    Algorith :
 
    START
            Accept character from user and store into the variable ch
 
            check the ch is between a,e,i,o,u
			if yes 
			   then it is vowel
			otherwise
			   it is a consonet
    END
*/

#include "Header.h"

int main()          // Entry point function
{
    char cValue = '\0';
	BOOLEAN bRet = FALSE;
    
    printf("Enter a character :\n");
    scanf("%c",&cValue);
    
    bRet = CheckVowel(cValue);      // Function call    Dukanat ja	
	
	if(bRet == TRUE)
	{
		printf("character is vowel\n");
	}
	else
	{
		printf("character is consonent\n");
	}
    
    return 0;
}
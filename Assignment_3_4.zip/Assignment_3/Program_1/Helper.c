#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      PrintEven
// Parameters    :      int
// Return value  :      void
// Description   :      Display Even numbers of a User given number
// Author        :      Anand Manchakrao Deshmukh
// Date          :      31 July 2020
//
//////////////////////////////////////////////////////////////

void PrintEven(int iNo) //Method Implementation;
{
	int iCnt1=0;
	int iCnt2=2;
	if(iNo <= 0)
	{
		return;
	}
	
	while(iCnt1 < iNo)
	{
		if(iCnt2%2 == 0)
		{
			printf("%d ",iCnt2);
			iCnt1++;
		}
		iCnt2++;
	}
    	
}
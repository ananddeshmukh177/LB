/*
    Problem statement : Write a program which accept one number from user and print that number of even numbers on screen.
*/
/*
    Algorith :
 
    START
            Accept number from user and store into the variable no
 
            
            Iterate till the counter is equal to number of even numbers.
			and display that number when even occurs
    END
*/
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue=0;             //Local Variable
		
	printf("Enter a Number:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	PrintEven(iValue);          //Function Call
		
	return 0;                 //Successful Termination
}

#include<stdio.h>     //Include standard io library

void PrintEven(int); //Method Prototype
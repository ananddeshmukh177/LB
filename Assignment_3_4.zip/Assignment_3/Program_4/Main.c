/*
Problem statement : Write a program which accept number from user and print even factors of that number.
*/

/*
    Algorith :
 
    START
            Accept character from user and store into the variable ch
 
            check the ch is between small a to z and
			sbstract 32 from that ascii value and display
			
			or check the ch is between Capital A to Z and
			add 32 from that ascii value and display
			
 
    END
*/

#include "Header.h"

int main()          // Entry point function
{
    char cValue = '\0';
    
    printf("Enter a character :\n");
    scanf("%c",&cValue);
    
    DisplayConvert(cValue);      // Function call    Dukanat ja	
    
    return 0;
}
















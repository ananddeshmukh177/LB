#include "Header.h"

//////////////////////////////////////////////////////////////
//
//  Function name : DisplayConvert
//  Input : Char
//  Output :    None
//  Description :   It is used to convert lower to upper and upper to lower case
//  Autor : Anand Manchakrao Deshmukh
//  Date :  31th July 2020
//
//////////////////////////////////////////////////////////////

void DisplayConvert ( char CValue)
{
	int cAns='\0';

	if(CValue >= 'a' && CValue <= 'z')
		{
			cAns=CValue-32;
			printf("Converted Character :%c" , cAns);
		}
	else if(CValue >= 'A' && CValue <= 'Z')
		{
			cAns=CValue+32;
			printf("Converted Character :%c" , cAns);
		}
}



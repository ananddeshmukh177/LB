#include<stdio.h>                   // Used for IO functions

typedef int BOOLEAN;                // New datatype as BOOLEAN treated as int

#define TRUE 1                      // User defined macro
#define FALSE 0                     // User defined macro

BOOLEAN ChkEvenOdd(int);            // Function prototype

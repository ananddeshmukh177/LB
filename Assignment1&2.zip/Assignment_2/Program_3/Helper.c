#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      int
// Return value  :      void
// Description   :      Display "HELLO" if number is less than 10 otherwise "DEMO"
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////

void Display(int iNo) //Method Implementation;
{
	if(iNo<10)
	{
		printf("HELLO");
	}		
	else
	{
		printf("DEMO");
	}
}
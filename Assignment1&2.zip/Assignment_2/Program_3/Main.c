/*
    Problem statement : Accept on number from user if number is less than 10 then print
                        “Hello” otherwise print “Demo”.
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue=0;             //Local Variable
		
	printf("ENTER A NUMBER :"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	Display(iValue);          //Function Call
		
	return 0;                 //Successful Termination
}
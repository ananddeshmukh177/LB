/*
    Problem statement : Accept one number from user and print that number of * on screen.
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue=0;             //Local Variable
		
	printf("How many stars do youo wanna print:"); //Display Statement
	scanf("%d",&iValue);      //Accept input
	Display(iValue);          //Function Call
		
	return 0;                 //Successful Termination
}
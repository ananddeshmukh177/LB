#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      int
// Return value  :      void
// Description   :      Display User given number of stars 
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////

void Display(int iNo) //Method Implementation;
{
	while(iNo>0)
	{
		printf("* ");
		iNo--;
	}		
}
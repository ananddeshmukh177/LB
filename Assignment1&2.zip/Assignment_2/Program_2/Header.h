
#include<stdio.h>     //Include standard io library

void Display(int); //Method Prototype
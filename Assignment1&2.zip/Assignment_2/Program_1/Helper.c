#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      PrintStars
// Parameters    :      int
// Return value  :      void
// Description   :      Display User given number of stars 
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////

void PrintStars(int iNo) //Method Implementation;
{
	int i=0;               //Local Variable;
	for(i=1;i<=iNo;i++)
	{
		printf("* ");
	}		
}
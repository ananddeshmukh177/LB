
#include<stdio.h>     //Include standard io library

void PrintStars(int); //Method Prototype
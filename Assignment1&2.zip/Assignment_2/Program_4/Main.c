/*
    Problem statement : Accept two numbers from user and display first number in second
						number of times.
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1=0;             //Local Variable
	
	int iValue2=0;             //Local Variable

		
	printf("ENTER FIRST NUMBER :"); //Display Statement
	scanf("%d",&iValue1);           //Accept input
	
	printf("ENTER SECOND NUMBER :"); //Display Statement
	scanf("%d",&iValue2);            //Accept input
	
	Display(iValue1,iValue2);          //Function Call
		
	return 0;                 //Successful Termination
}
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      int
// Return value  :      void
// Description   :      Display "FIRST" number "SECOND" number of times
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////

void Display(int iNo1,int iNo2) //Method Implementation;
{
	int i=0;
	for(i=1;i<=iNo2;i++)
	{
		printf("%d ",iNo1);
	}
}
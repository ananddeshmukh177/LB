/*
    Problem statement : Write a Program for Division of two Numbers 
*/


#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1=10;           //Local Variable
	int iValue2=5;            //Local Variable
	
	int iResult=0;            //Local Variable
	
	iResult=Divide(iValue1,iValue2);   //Function Call
	
	printf("Division is :%d",iResult); //Display Statement
	
	return 0;                 //Successful Termination
}
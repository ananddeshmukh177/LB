
#include<stdio.h>     //Include standard io library

int Divide(int,int);  //Method Prototype
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Divide
// Parameters    :      Integer
// Return value  :      Integer
// Description   :      Divison of two Numbers
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////

int Divide(int iNo1,int iNo2) //Method Implementation;
{
	int IAns=0;               //Local Variable;
	if(iNo2<=0)               //Check Whether number is 0 or -1; 
	{
		return -1;            //Errormous Return
	}
	IAns=iNo1/iNo2;           //Division is Stored in IAns Variable
	
	return IAns;              //Return IAns
}
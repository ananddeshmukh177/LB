#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;


//////////////////////////////////////////////////////////////
//
// Function name :      ChkDivisible
// Parameters    :      int
// Return value  :      BOOLEAN
// Description   :      Check Number is Divisible by 5 or not
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////


BOOLEAN ChkDivisible(int iNo) //Method Implementation;
{
	
	if(iNo%5==0)              //Check Divisability
	{
		return TRUE;	      
	}
	else 
	{
		return FALSE;
	}
}
/*
    Problem statement : Accept one number and check whether is is divisible by 5 or not.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iNum1=0;              //Local Variable
	BOOLEAN bResult=FALSE;
	printf("Enter a Number :");//Display Statement 
	scanf("%d",&iNum1);        //Accept Number
	bResult=ChkDivisible(iNum1);//Function Call
	
	if(bResult==TRUE)          //Check if true 
	{
		printf("Number is divisible by 5");
	} 
	else                       //Else Condition
	{
		printf("Number is not divisible by 5");
	}
	return 0;                 //Successful Termination
}
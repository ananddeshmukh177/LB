#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;


//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      void
// Return value  :      void
// Description   :      Print "Marvellous" 5 times
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////


void Display() //Method Implementation;
{
	int i=0;
	for(i=1;i<=5;i++)
	{
		printf("Marvellous\n");	
	}
}

#include<stdio.h>     //Include standard io library

void Display();       //Method Prototype
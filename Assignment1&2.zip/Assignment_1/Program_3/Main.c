/*
    Problem statement : Print Number 5 to 1 on screen
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	Display();                //Function Call
	return 0;                 //Successful Termination
}
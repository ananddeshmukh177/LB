#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;


//////////////////////////////////////////////////////////////
//
// Function name :      Display
// Parameters    :      void
// Return value  :      void
// Description   :      Print 5 to 1 Numbers on Screen
// Author        :      Anand Manchakrao Deshmukh
// Date          :      24 July 2020
//
//////////////////////////////////////////////////////////////


void Display() //Method Implementation;
{
	int i=0;
	for(i=5;i>=1;i--)
	{
		printf("%d\n",i);	
	}
}

#include<stdio.h>     //Include standard io library

void Accept(int); //Method Prototype
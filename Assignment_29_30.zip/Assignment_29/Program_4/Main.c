/*
Problem Statement: 

Write a program which accept string from user reverse that string
in place.
Input : “abcd”
Output : “dcba”
Input : “abba”
Output : “abba”

*/

#include"Header.h"


int main()
{
	char arr[30];
	char cValue = '\0';
	int iRet = 0;
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	
	printf("Please Enter a character\nInput :");
	scanf(" %c",&cValue);
	
	iRet = LastOcc(arr,cValue);

	printf("Last Occurance of character is :%d\n",iRet);
	
	return 0;
}
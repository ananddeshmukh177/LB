#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : LastOcc
//Parameters    : char
//Return Value  : void
//Description   : it is used to find last occ index.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int LastOcc(char arr[],char cValue)
{	
	int i = 0;
	int len = 0;
	if(arr == NULL)
	{
		return MEMORY_ERROR;
	}
	
	while(arr[i] != '\0')
	{
		len++;
		i++;
	}

	int j = len-1;
	while(j >= 0)
	{
		if(arr[j]==cValue)
		{
			break;
		}
		j--;
	}
	
	if(j>=0)
	{
		return j;
	}
	else
	{
		return -1;
	}
	
}

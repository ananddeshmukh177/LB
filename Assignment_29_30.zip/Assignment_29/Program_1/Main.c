/*
Problem Statement: 

Write a program which accept string from user and count number of
white spaces
Input : “MarvellouS”
Output : 0
Input : “MarvellouS Infosystems”
Output : 1
Input : “MarvellouS Infosystems by Piyush Manohar Khairnnar”
Output : 5  

*/

#include"Header.h"


int main()
{
	char arr[30];
	BOOL bRet = FALSE;
	char cValue = '\0';
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	
	printf("Please Enter a character\nInput :");
	scanf(" %c",&cValue);//Before reading the character "Whitespace" is necessary

	
	bRet = ChKPresent(arr,cValue);
	

	if(bRet == TRUE)
	{
		printf("Character is Present\n");
	}
    else
	{
		printf("Character is not Present\n");
	}		
	return 0;
}
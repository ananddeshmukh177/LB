#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChKPresent
//Parameters    : char
//Return Value  : BOOL
//Description   : it is used to check char is present in string or not.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL ChKPresent(char *cPtr,char cValue)
{	
	int iCnt = 0;
	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	
	while(*cPtr != '\0')
	{
		if(*cPtr == cValue)
		{
		 iCnt++;
		}
		
		cPtr++;
	}
	if(iCnt > 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

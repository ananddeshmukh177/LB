#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrrevX
//Parameters    : char
//Return Value  : void
//Description   : it is used to reverse the string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrrevX(char arr[])
{	
	int i = 0;
	int len = 0;
	if(arr == NULL)
	{
		return;
	}
	
	while(arr[i] != '\0')
	{
		len++;
		i++;
	}
	int j = len-1;
	int k = 0;
	while(k<j)
	{
		int temp = arr[k];
		arr[k]=arr[j];
		arr[j]=temp;
		k++;
		j--;
	}
	
}

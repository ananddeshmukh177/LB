/*
Problem Statement: 

Write a program which accept string from user reverse that string
in place.
Input : “abcd”
Output : “dcba”
Input : “abba”
Output : “abba”

*/

#include"Header.h"


int main()
{
	char arr[30];
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	StrrevX(arr);

	printf("Modified String is :%s\n",arr);
	
	return 0;
}
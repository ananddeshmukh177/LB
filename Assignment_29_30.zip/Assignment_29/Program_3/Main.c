/*
Problem Statement: 

Write a program which accept string from user and accept one
character. Return index of first occurrence of that character.

Input : “Marvellous Multi OS”
M
Output : 0

Input : “Marvellous Multi OS”
W
Output : -1

Input : “Marvellous Multi OS”
e
Output : 4  

*/

#include"Header.h"


int main()
{
	char arr[30];
	int iRet = 0;
	char cValue = '\0';
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	
	printf("Please Enter a character\nInput :");
	scanf(" %c",&cValue);//Before reading the character "Whitespace" is necessary

	
	iRet = FirstOcc(arr,cValue);

	printf("First occurance is :%d\n",iRet);
	
	return 0;
}
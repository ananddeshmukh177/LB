#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : FirstOcc
//Parameters    : char
//Return Value  : int
//Description   : it is used to check First Occ of char in string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int FirstOcc(char arr[],char cValue)
{	
	int i = 0, j = 0;
	int len = 0;
	if(arr == NULL)
	{
		return MEMORY_ERROR;
	}
	
	while(arr[i] != '\0')
	{
		len++;
		i++;
	}
	
	while(arr[j] != '\0')
	{
		if(arr[j] == cValue)
		{
			break;
		}
		
		j++;
	}
	if(j >=0 && j < len)
	{
		return j;
	}
	else
	{
		return -1;
	}
}

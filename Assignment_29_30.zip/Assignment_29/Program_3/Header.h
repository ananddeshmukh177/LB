#include<stdio.h>     //Header File 
//typedef int BOOL;
//#define TRUE 1
//#define FALSE 0
#define MEMORY_ERROR -2
    
int FirstOcc(char *,char);  //Function Prototype/Decleration
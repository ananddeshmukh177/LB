#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CharCount
//Parameters    : char
//Return Value  : int
//Description   : it is used to check frequency of char in string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int CharCount(char *cPtr,char cValue)
{	
	int iCnt = 0;
	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	
	while(*cPtr != '\0')
	{
		if(*cPtr == cValue)
		{
		 iCnt++;
		}
		
		cPtr++;
	}
	
	return iCnt;
}

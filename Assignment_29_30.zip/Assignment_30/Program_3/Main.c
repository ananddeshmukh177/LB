/*
Problem Statement: 

Write a program which accept string from user and copy capital
characters of that string into another string.
Input : “Marvellous Multi OS”
Output : “MMOS”

*/

#include"Header.h"


int main()
{
	char arr[30];
	char brr[30];

	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	StrcpyX2(arr,brr);
	
	printf("Capital String is:%s",brr);
			
	return 0;
}
#include<stdio.h>     //Header File 

    
void StrcpyX2(char *,char *);  //Function Prototype/Decleration
#include<stdio.h>     //Header File 

    
void StrcpyX2(char *,char *,int);  //Function Prototype/Decleration
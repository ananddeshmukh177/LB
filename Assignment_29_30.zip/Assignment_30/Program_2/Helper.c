#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcpyX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy string into another string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcpyX2(char src[],char dest[],int iCnt)
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}
	int i = 0;

	while(i < iCnt)
	{
		dest[i]=src[i];
		i++;
	}
	
	dest[i] = '\0';
	
}

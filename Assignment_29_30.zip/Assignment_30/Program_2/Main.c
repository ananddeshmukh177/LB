/*
Problem Statement: 

Write a program which accept string from user and copy the
contents of that string into another string. (Implement strncpy()
function)

Input : “Marvellous Multi OS”
10
Output : “Marvellous

Note : If third parameter is greater than the size of source string then
copy whole string into destination.

*/

#include"Header.h"


int main()
{
	char arr[30];
	char brr[30];
	int iValue = 0;

	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	
	printf("How many characters do you wanna print\nInput :");
	scanf("%d",&iValue);

	StrcpyX2(arr,brr,iValue);
	
	printf("Copied and Updated String is:%s",brr);
			
	return 0;
}
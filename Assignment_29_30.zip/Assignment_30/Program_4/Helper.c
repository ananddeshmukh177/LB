#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcpyX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy Capital string into another string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcpyX2(char src[],char dest[])
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}
	int i = 0;
	int j = 0;

	while(src[i] != '\0')
	{
		if((src[i] >= 'a') && (src[i] <= 'z'))
		{
			dest[j]=src[i];
			j++;
		}
		i++;
	}
	dest[j]='\0';
	
}

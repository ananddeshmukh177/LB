#include"Header.h"//Include Header File
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcatX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy Concat string into another string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
void StrcatX(char src[],char dest[])
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}	
	
	while(*src != '\0')
	{
		src++;
	}
	*src = ' ';
	src++;
	while(*dest != '\0')
	{
		
		*src=*dest;
		src++;
		dest++;
	}
	*src='\0';
	
}
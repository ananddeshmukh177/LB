/*
Problem Statement: 

Write a program which 2 strings from user and concat second string
after first string. (Implement strcat() function).

Input : “Marvellous Infosystems”
		“Logic Building”
Output: “Marvellous Infosystems Logic Building”

*/

#include"Header.h"


int main()
{
	char arr[60];
	char brr[30];

	printf("Please Enter First a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	
	printf("Please Enter Second a String\nInput :");
	scanf(" %[^'\n']s",brr);

	StrcatX(arr,brr);
	
	printf("Concated String is:%s",arr);
			
	return 0;
}
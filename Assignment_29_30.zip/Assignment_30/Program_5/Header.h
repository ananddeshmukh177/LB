#include<stdio.h>     //Header File 

    
void StrcatX(char *,char *);  //Function Prototype/Decleration
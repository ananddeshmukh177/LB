#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcpyX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy string into another string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 23/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcpyX(char src[],char dest[])
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}
	int i = 0;

	while(src[i] != '\0')
	{
		dest[i]=src[i];
		i++;
	}
	
	dest[i]='\0';
}

/*
Problem Statement: 

Write a program which accept string from user and copy the
contents of that string into another string. (Implement strcpy()
function)
Input : “Marvellous Multi OS”
Output : “Marvellous Multi OS” in another string  

*/

#include"Header.h"


int main()
{
	char arr[30];
	char brr[30];

	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	StrcpyX(arr,brr);
	
	printf("Copied String is:%s",brr);
			
	return 0;
}
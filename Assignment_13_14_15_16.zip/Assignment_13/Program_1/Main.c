/*
Problem Statement: Accept number from user and display below pattern.

Input : 5
Output : A B C D E 

*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue = 0;     //Local Variable
 	int iRet = 0;     //Local Variable

	printf("Enter a Number:");   //Display Statement
	scanf("%d",&iValue);  //Accept Statement
	Pattern(iValue);     //Function Call
	
	return 0;           //return Succesfully
}
#include<stdio.h>         
void Pattern(int);//Method Prototype
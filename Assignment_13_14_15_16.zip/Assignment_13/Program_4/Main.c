/*
Problem Statement: 4. Accept number from user and display below pattern.
Input : 4
Output : # 1 * # 2 * # 3 * # 4 * 
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue = 0;     //Local Variable
 	int iRet = 0;     //Local Variable

	printf("Enter a Number:");   //Display Statement
	scanf("%d",&iValue);  //Accept Statement
	Pattern(iValue);     //Function Call
	
	return 0;           //return Succesfully
}
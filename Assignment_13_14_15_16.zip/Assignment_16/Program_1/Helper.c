#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Pattern
//Parameters    : int
//Return Value  : void
//Description   : it is used to display pattern.
//Author        : Anand Manchakrao Deshmukh
//Date          : 11/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Pattern(int iNo1,int iNo2)//Method Implimentation
{
	int iCnt1 = 0;
	int iCnt2 = 0;
	int iNumber = 1;


	if(iNo1 < 0)
	{
		iNo1 = -iNo1;
	}
	if(iNo2< 0)
	{
		iNo2= -iNo2;
	}
	
	for(iCnt1=1 ; iCnt1<=iNo1 ; iCnt1++)
	{
		
			for(iCnt2=1;iCnt2 <=iNo2;iCnt2++)
			{
				printf("%d\t",iNumber);
				iNumber++;
				if(iNumber > 9)
				{
					iNumber = 1;
				}
			}
			
				printf("\n");
				//umber

	}
}	
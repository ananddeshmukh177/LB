/*
Problem Statement: Accept number of rows and number of columns from user and display below
pattern.
Input : iRow = 4 iCol = 4
Output : 	A B C D
			a b c d
			A B C D
			a b c d 
 
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue1 = 0;     //Local Variable
	int iValue2 = 0;     //Local Variable

 	int iRet = 0;     //Local Variable

	printf("Enter Rows and Columns:");   //Display Statement
	scanf("%d %d",&iValue1,&iValue2);  //Accept Statement
	Pattern(iValue1,iValue2);     //Function Call
	
	return 0;           //return Succesfully
}
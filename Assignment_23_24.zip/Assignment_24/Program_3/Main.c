/*
Problem Statement: 

Accept N numbers from user and return the difference between largest
and smallest number.
Input : N : 6
Elements : 85 66 3 66 93 88
Output : 90 (93 -3)

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	int *ptr = NULL;
	int iRet = 0;
	
	printf("Enter a Size of Array :");
	scanf("%d",&iValue);
	
	if(iValue == 0)
	{
		printf("ERROR: MEMORY ERROR");
		return -1;//erronomous return
	}	
	
	ptr = (int *)malloc(sizeof(int)*iValue);
	
	if(ptr == NULL)
	{
		printf("ERROR: UNABLE TO ALLOCATE MEMORY");
		return -1;//erronomous return
	}
	
	printf("Enter Array Elements: ");
	for(int i = 0 ; i<iValue ; i++)
	{
		scanf("%d",&ptr[i]);
	}
	
	iRet = Difference(ptr,iValue);
	
	if(iRet == MEMORY_ERROR)
	{
		printf("ERROR: MEMORY ERROR");
	}
	else if(iRet == SIZE_ERROR)
	{
		printf("ERROR: MEMORY ERROR");
	}
	else
	{
		printf("Difference Between Maximum and Minimum Number is:%d",iRet);
	}
	
	return 0;
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : DigitsSum
//Parameters    : int
//Return Value  : void
//Description   : it is used to give the Digits Sum.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void DigitsSum(int *arr,int iSize)  //Array is pointer which stores base address;
{	
    printf("Addition of digits:\n");
	for(int i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		int iSum = 0;
		int iDigit = 0;
		while(arr[i] != 0)
		{
			iDigit = arr[i]%10;
			iSum += iDigit;
			arr[i]=arr[i]/10;
		}
		
		printf("%d ",iSum);
	}
}

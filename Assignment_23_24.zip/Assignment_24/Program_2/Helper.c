#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Minimum
//Parameters    : int
//Return Value  : int
//Description   : it is used to give the Minimum number from array elements.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int Minimum(int *arr,int iSize)  //Array is pointer which stores base address;
{	
	if(arr == NULL)  //if User given address is NULL
	{
		return MEMORY_ERROR;
	}
	
	if(iSize <= 0)   //if User given Size is 0 or NULL
	{
		return SIZE_ERROR;
	}
	
	int iMin = arr[0];
	for(int i=1 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		if(arr[i] < iMin)  //
		{
			iMin = arr[i];
		}
	}

	return iMin;
}

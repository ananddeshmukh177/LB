#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Digits
//Parameters    : int
//Return Value  : void
//Description   : it is used to give the number which contain 3 digits in it.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Digits(int *arr,int iSize)  //Array is pointer which stores base address;
{	
	int iDigit = 0;
	int i = 0;
	for(i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		int iCnt = 0;
		int temp = arr[i];
		while(arr[i] != 0)
		{
			iDigit = arr[i]%10;				
			iCnt++;
			arr[i]=arr[i]/10;
		}
		
		if(iCnt == 3)
		{
			printf("%d ",temp);
		}
	}
}

#include<stdio.h>     //Header File 
#include<stdlib.h>    //Header File for malloc() calloc() realloc() free()  

typedef int BOOL; 

#define TRUE 1
#define FALSE 0

#define SIZE_ERROR -1   //MACRO IS DEFINE FOR SIZE ERROR
#define MEMORY_ERROR -2 //MACRO Is DEFINE FOR MEMORY ERROR

//malloc() ->Used to allocate memory structure/User defined
//calloc() ->for array
//realloc() ->increase/decrease size of array
//free() ->delete memory   
      
BOOL Check(int *,int,int);  //Function Prototype/Decleration
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : LastOcc
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate Last Occurance of given Number.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int LastOcc(int *arr,int iSize,int iNo)  //Array is pointer which stores base address;
{
	if(arr == NULL)  //if User given address is NULL
	{
		return SIZE_ERROR;
	}
	
	if(iSize <= 0)   //if User given Size is 0 or NULL
	{
		return MEMORY_ERROR;
	}
	int iIndex = -1;			
	for(int i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		if( arr[i] == iNo )  //
		{
			iIndex=i;
		}
	}
	if(iIndex >= 0)
	{
		return iIndex;
	}
	else
	{
		return -1;
	}
}

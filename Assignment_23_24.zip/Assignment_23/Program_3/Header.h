#include<stdio.h>     //Header File 
#include<stdlib.h>    //Header File for malloc() calloc() realloc() free()  

#define SIZE_ERROR -2   //MACRO IS DEFINE FOR SIZE ERROR
#define MEMORY_ERROR -3 //MACRO Is DEFINE FOR MEMORY ERROR

//malloc() ->Used to allocate memory structure/User defined
//calloc() ->for array
//realloc() ->increase/decrease size of array
//free() ->delete memory   
      
int LastOcc(int *,int,int);  //Function Prototype/Decleration
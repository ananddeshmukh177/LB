/*
Problem Statement: 

Accept N numbers from user and accept Range, Display all elements from
that range
Input : N : 6
Start: 60
End : 90
Elements : 85 66 3 76 93 88
Output : 66 76 88

Input : N : 6
Start: 30
End : 50
Elements : 85 66 3 76 93 88
Output :  
*/

#include"Header.h"


int main()  //Execution Starts
{
	int iValue1 = 0;
	int iValue2 = 0;
	int iValue3 = 0;
	int *ptr = NULL;  //Pointers Default Value is NULL
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue1);                 ////Accept Array Size Ex:5
	
	if(iValue1 == 0)//if user given value zero "malloc" accept zero value return address but doesnt create memory location
	{//so if we are trying to store the value in that case segmentation falt occurs(OS doesnt give memory )
     //if the value is get store there may be space remain (but it is not recommended)	
		printf("ERROR : MEMORY IS NOT ALLOCATED");
		return -1;
	}
	
	ptr = (int *)malloc(sizeof(int)*iValue1); //Dynamic Memory Allocation
	//(int *) is used for type casting becouse malloc return void pointer
	//for example malloc return 100 as a base address
	
	if(ptr == NULL) //Check memory available or not
	{
		printf("ERROR : UNABLE TO ALLOCATE MEMORY");
		return -1;
	}
	
	printf("Enter Starting Point of Range: ");
	scanf("%d",&iValue2);                ////Accept element to find the frequency(occurance) Ex:5
	
	
	printf("Enter Ending Point of Range: ");
	scanf("%d",&iValue3);       
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue1 ; i++)
	{
		scanf("%d",&ptr[i]);         //Accept Array Elements 
	}
	
	Range(ptr,iValue1,iValue2,iValue3);   //Function call Check(100,5,5)
		
	free(ptr);    //Free Memory
	
	return 0;     //Successful Termination
	
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Range
//Parameters    : int
//Return Value  : void
//Description   : it is used to Dispaly Numbers in given range.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Range(int *arr,int iSize,int iStart,int iEnd)  //Array is pointer which stores base address;
{
	if(arr == NULL)  //if User given address is NULL
	{
		return;
	}
	
	if(iSize <= 0)   //if User given Size is 0 or NULL
	{
		return;
	}
	printf("Elements in the given Range are :");
	for(int i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		if( arr[i] >= iStart && arr[i] <= iEnd )  //
		{
			printf("%d ",arr[i]);
		}
	}
}

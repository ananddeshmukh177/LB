#include<stdio.h>     //Header File 
#include<stdlib.h>    //Header File for malloc() calloc() realloc() free()  

#define SIZE_ERROR -2
#define MEMORY_ERROR -3
#define ODD_NOT_FOUND 0

//malloc() ->Used to allocate memory structure/User defined
//calloc() ->for array
//realloc() ->increase/decrease size of array
//free() ->delete memory   
      
int Product(int *,int);  //Function Prototype/Decleration
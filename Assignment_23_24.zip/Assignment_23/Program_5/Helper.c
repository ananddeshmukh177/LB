#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Product
//Parameters    : int
//Return Value  : int
//Description   : it is used to give the product of odd array elements.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int Product(int *arr,int iSize)  //Array is pointer which stores base address;
{
	int iFlag = 0;
	
	if(arr == NULL)  //if User given address is NULL
	{
		return MEMORY_ERROR;
	}
	
	if(iSize <= 0)   //if User given Size is 0 or NULL
	{
		return SIZE_ERROR;
	}
	
	int iMult = 1;
	for(int i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		if((arr[i]%2)!=0)  //
		{
			iFlag =1;
			iMult=iMult*arr[i];
		}
	}
	
	if(iFlag == 1)
	{
		return iMult;
	}
	else
	{
		return ODD_NOT_FOUND; //if ODD NUMBER NOT FOUND IN ARRAY
	}
}

#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : FirstOcc
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate First Occurance of given Number.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int FirstOcc(int *arr,int iSize,int iNo)  //Array is pointer which stores base address;
{
	if(arr == NULL)  //if User given address is NULL
	{
		return SIZE_ERROR;
	}
	
	if(iSize <= 0)   //if User given Size is 0 or NULL
	{
		return MEMORY_ERROR;
	}
	
	for(int i=0 ; i<iSize ; i++)//ITERATE LOOP FROM 0 TO Size-1
	{
		if( arr[i] == iNo )  //
		{	
			return i;
		}
	}
	return -1;     //
}

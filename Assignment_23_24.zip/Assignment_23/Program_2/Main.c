/*
Problem Statement: 

Accept N numbers from user and accept one another number as NO ,
return index of first occurrence of that NO.
 Input : N : 6
 NO: 66
 Elements : 85 66 3 66 93 88
 Output : 1

 Input : N : 6
 NO: 12
 Elements : 85 11 3 15 11 111 
 Output : -1  
 
*/

#include"Header.h"


int main()  //Execution Starts
{
	int iValue1 = 0;
	int iValue2 = 0;
	int iRet = 0; 
	int *ptr = NULL;  //Pointers Default Value is NULL
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue1);                 ////Accept Array Size Ex:5
	
	if(iValue1 == 0)//if user given value zero "malloc" accept zero value return address but doesnt create memory location
	{//so if we are trying to store the value in that case segmentation falt occurs(OS doesnt give memory )
     //if the value is get store there may be space remain (but it is not recommended)	
		printf("ERROR : MEMORY IS NOT ALLOCATED");
		return -1;
	}
	
	ptr = (int *)malloc(sizeof(int)*iValue1); //Dynamic Memory Allocation
	//(int *) is used for type casting becouse malloc return void pointer
	//for example malloc return 100 as a base address
	
	if(ptr == NULL) //Check memory available or not
	{
		printf("ERROR : UNABLE TO ALLOCATE MEMORY");
		return -1;
	}
	
	printf("Enter Element to find INDEX: ");
	scanf("%d",&iValue2);                ////Accept element to find the frequency(occurance) Ex:5
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue1 ; i++)
	{
		scanf("%d",&ptr[i]);         //Accept Array Elements 
	}
	
	iRet = FirstOcc(ptr,iValue1,iValue2);   //Function call Check(100,5,5)
	
	if(iRet == SIZE_ERROR)              //SIZE_ERROR
	{
		printf("ERROR : SIZE_ERROR");
	}
	else if(iRet == MEMORY_ERROR)      //MEMORY ERROR
	{
		printf("ERROR : MEMORY_ERROR");
	}
    else
	{
		printf("INDEX OF FIRST OCCRANCE IS:%d",iRet);
	}	
	
	free(ptr);    //Free Memory
	
	return 0;     //Successful Termination
	
}
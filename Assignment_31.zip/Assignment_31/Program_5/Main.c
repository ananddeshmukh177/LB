/*
Problem Statement: 

Write a program which accept string from user and copy that
characters of that string into another string by toggling the case.
Input : “Marvellous Python 2”
Output : “mARVELLOUS pYTHON 2”  

*/

#include"Header.h"


int main()
{
	char arr[30];
	char brr[30];

	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	StrcpyXX(arr,brr);
	
	printf("Copied String is:%s",brr);
			
	return 0;
}
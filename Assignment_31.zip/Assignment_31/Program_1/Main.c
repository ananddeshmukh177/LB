/*
Problem Statement: 

Write a program which accept string from user and copy that
characters of that string into another string in reverse order.
Input : “Marvellous Python”
Output : “nohtyP suollevraM” 

*/

#include"Header.h"


int main()
{
	char arr[30];
	char brr[30];

	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);

	StrcpyX(arr,brr);
	
	printf("Copied Reverse String is:%s",brr);
			
	return 0;
}
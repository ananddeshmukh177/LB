#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcpyX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy reverse string into another string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 31/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcpyX(char src[],char dest[])
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}
	int i = 0;
	int len = 0;
	while(src[i] != '\0')
	{
		i++;
		len++;
	}

	int j = len -1; 
	i = 0;
	while(j >= 0)
	{
		dest[i]=src[j];
		i++;
		j--;
	}
	
	dest[i]='\0';
}

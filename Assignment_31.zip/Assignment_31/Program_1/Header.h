#include<stdio.h>     //Header File 

    
void StrcpyX(char *,char *);  //Function Prototype/Decleration
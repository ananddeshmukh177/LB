#include<stdio.h>     //Header File 

void StrcpyXX(char *,char *);  //Function Prototype/Decleration
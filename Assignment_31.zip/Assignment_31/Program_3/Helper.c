#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : StrcpyXX
//Parameters    : char *,char *
//Return Value  : void
//Description   : it is used to copy reverse string into another string and copying small to Capital
//Author        : Anand Manchakrao Deshmukh
//Date          : 31/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void StrcpyXX(char src[],char dest[])
{	
	if(src == NULL)
	{
		return;
	}
	if(dest == NULL)
	{
		return;
	}
	
	while(*src != '\0')
	{
		if(*src >= 'a' && *src <= 'z')
		{
			*src = *src-32;
		}	
		*dest = *src;
		
		*src++;
		*dest++;
	}
	
	*dest='\0';
}

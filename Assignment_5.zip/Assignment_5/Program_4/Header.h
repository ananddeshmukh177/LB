#include<stdio.h>


int Multiply(int,int,int);
/*
    Problem statement : Write a program which accept three numbers and print its multiplication.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iValue2 = 0;
	int iValue3 = 0;

	int iAns = 0;	//Local Variable
		
	printf("Enter 3 Numbers:"); //Display Statement
	scanf("%d %d %d",&iValue1,&iValue2,&iValue3);       //Accept input
	iAns = Multiply(iValue1,iValue2,iValue3);          //Function Call
	printf("Multiiplication of three numbers is : %d",iAns);
	
	return 0;                 //Successful Termination
}
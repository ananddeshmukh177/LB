#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Multiply
// Parameters    :      int
// Return value  :      int
// Description   :      Multiply 3 Numbers 
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

int Multiply(int iNo1,int iNo2,int iNo3) //Method Implementation;
{
	//BOOLEAN bRes = FALSE;
	return iNo1*iNo2*iNo3;
}
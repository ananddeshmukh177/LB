/*
    Problem statement : Write a program which accept total marks & obtained marks from user and
calculate percentage.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iValue2 = 0;

	float iAns = 0.0f;	//Local Variable
		
	printf("Enter Total Marks and Obtained Marks:"); //Display Statement
	scanf("%d %d",&iValue1,&iValue2);       //Accept input
	iAns = Percentage(iValue1,iValue2);          //Function Call
	printf("Percentage : %f",iAns);
	
	return 0;                 //Successful Termination
}
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      Percentage
// Parameters    :      int
// Return value  :      float
// Description   :      Percentage Calculation 
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

float Percentage(int iNo1,int iNo2) //Method Implementation;
{
	//BOOLEAN bRes = FALSE;
	float fRes= ((float)iNo2/(float)iNo1);
	
	return fRes*100;
}
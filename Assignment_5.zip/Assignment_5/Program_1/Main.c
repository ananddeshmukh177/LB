#include<stdio.h>

int main()
{
	char name[30];
	printf("please enter full name :");
    scanf("%[^\n]",name);
	printf("%s",name);

	return 0;
}
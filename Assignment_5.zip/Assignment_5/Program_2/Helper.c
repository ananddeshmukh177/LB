#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      ChkGreater
// Parameters    :      int
// Return value  :      int
// Description   :      calculate Greater Number
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

BOOLEAN ChkGreater(int iNo1) //Method Implementation;
{
	//BOOLEAN bRes = FALSE;
	
	if(iNo1 > 100)
	{
		return TRUE;
	}
	else
	{
	    return FALSE;	
	}
	
}
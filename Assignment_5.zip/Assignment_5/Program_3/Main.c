/*
    Problem statement : Write a program which accept one number from user and check whether that
                        number is equal or not.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iValue2 = 0;

	BOOLEAN iAns = FALSE;	//Local Variable
		
	printf("Enter a Number 1:"); //Display Statement
	scanf("%d",&iValue1);      //Accept input
	printf("Enter a Number 2:"); //Display Statement
	scanf("%d",&iValue2);      //Accept input
	iAns = ChkEqual(iValue1,iValue2);          //Function Call
	if(iAns==TRUE)
	{
		printf("equal");
	}
	else
	{
		printf("not equal");
	}	
	return 0;                 //Successful Termination
}
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      ChkEqual
// Parameters    :      int
// Return value  :      int
// Description   :      calculate Number equal or not
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

BOOLEAN ChkEqual(int iNo1,int iNo2) //Method Implementation;
{
	//BOOLEAN bRes = FALSE;
	
	if(iNo1 == iNo2)
	{
		return TRUE;
	}
	else
	{
	    return FALSE;	
	}
	
}
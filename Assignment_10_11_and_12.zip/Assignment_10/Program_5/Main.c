/*
Problem Statement:   Write a program which accept area in square feet and convert it into square
meter. (1 square feet = 0.0929 Square meter)   
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	float fSquareFeet = 0.0f;      //Local Variable
	double dSquareMeter = 0.0 ;


	printf("Enter a area into square feet :");   //Display Statement
	scanf("%f",&fSquareFeet);         //Accept Statement

	dSquareMeter = SFtoSM(fSquareFeet);//Function Call
	printf("Area into Square Meter is : %lf",dSquareMeter);
	
	return 0;                            //return Succesfully
}
#include<stdio.h>         
double SFtoSM(float);//Method Prototype
/*
Problem Statement:  Write a program which accept width & height of rectangle from user and calculate
its area. (Area = Width * Height)  
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	float fWidth = 0.0f;      //Local Variable
	float fHeight = 0.0f;     //Local Variable
	double dArea = 0.0;       //Local Variable

	printf("Enter a Width :");   //Display Statement
	scanf("%f",&fWidth);         //Accept Statement
	printf("Enter a Height :");  //Display Statement
	scanf("%f",&fHeight);        //Accept Statement

	dArea = AreaOfRectangle(fWidth,fHeight);//Function Call
	printf("Area of Rectangle is : %lf",dArea);
	
	return 0;                            //return Succesfully
}
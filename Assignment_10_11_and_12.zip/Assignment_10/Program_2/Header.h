#include<stdio.h>         
double AreaOfRectangle(float,float);//Method Prototype
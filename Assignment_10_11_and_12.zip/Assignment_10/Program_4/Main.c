/*
Problem Statement:  Write a program which accept temperature in Fahrenheit and convert it into
celsius. (1 celsius = (Fahrenheit -32) * (5/9))   
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	float fFahrenheit = 0.0f;      //Local Variable
	double fCelsius = 0.0 ;


	printf("Enter a temperature into Fahrenheit :");   //Display Statement
	scanf("%f",&fFahrenheit);         //Accept Statement

	fCelsius = FahrenheitTOCelsius(fFahrenheit);//Function Call
	printf("Temperature into Celsius is : %lf",fCelsius);
	
	return 0;                            //return Succesfully
}
#include<stdio.h>         
double FahrenheitTOCelsius(float);//Method Prototype
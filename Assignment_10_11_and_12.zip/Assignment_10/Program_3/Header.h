#include<stdio.h>         
int KMtoM(int);//Method Prototype
/*
Problem Statement:  Write a program which accept distance in kilometre and convert it into meter. (1
kilometre = 1000 Meter)  
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iKM = 0;      //Local Variable
	int iM =0 ;


	printf("Enter a Distance in KiloMeter :");   //Display Statement
	scanf("%d",&iKM);         //Accept Statement

	iM = KMtoM(iKM);//Function Call
	printf("Distance into Meter is : %d",iM);
	
	return 0;                            //return Succesfully
}
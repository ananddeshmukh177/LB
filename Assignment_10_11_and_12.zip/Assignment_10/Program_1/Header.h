#include<stdio.h>         
float AreaOfCircle(float);//Method Prototype
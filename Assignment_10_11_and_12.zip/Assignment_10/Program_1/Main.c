/*
Problem Statement: Write a program which accept radius of circle from user and calculate its area.
Consider value of PI as 3.14. (Area = PI * Radius * Radius) 
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	float iRadius = 0.0f;     //Local Variable
	double dArea = 0.0f;      //Local Variable
	
	printf("Enter a radius :");   //Display Statement
	scanf("%f",&iRadius);         //Accept Statement
	dArea = AreaOfCircle(iRadius);//Function Call
	printf("Area of Circle is : %lf",dArea);
	
	return 0;           //return Succesfully
}
#include<stdio.h>         
void Range(int,int);//Method Prototype
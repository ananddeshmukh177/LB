/*
Problem Statement:Write a program which accept accept range from user and display all numbers in
between that range in reverse order.
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue1 = 0;     //Local Variable
	int iValue2 = 0;     //Local Variable

	printf("Enter a two numbers :");   //Display Statement
	scanf("%d %d",&iValue1,&iValue2);  //Accept Statement
	Range(iValue1,iValue2);     //Function Call
	
	return 0;           //return Succesfully
}
/*
Problem Statement: Write a program which accept range from user and return addition of all even
numbers in between that range. (Range should contains positive numbers only)
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue1 = 0;     //Local Variable
	int iValue2 = 0;     //Local Variable
	int iAddition = 0;

	printf("Enter a two numbers :");   //Display Statement
	scanf("%d %d",&iValue1,&iValue2);  //Accept Statement
    iAddition = Range(iValue1,iValue2);     //Function Call
	if(iAddition == 0)
	{
		printf("Invalid Input");
	}	
	else
	{	
		printf("Addition is: %d",iAddition);
	}
	return 0;           //return Succesfully
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Range
//Parameters    : int
//Return Value  : void
//Description   : it is used to calculate Range for given numbers
//Author        : Anand Manchakrao Deshmukh
//Date          : 07/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Range(int iNo1,int iNo2)//Method Implimentation
{
	int iCnt = 0;
	
	if(iNo2 < iNo1)
	{
		printf("Invalid Input");
	}
	
	for(iCnt=iNo1 ; iCnt <= iNo2 ; iCnt++)
	{
		if(( iCnt % 2 ) == 0)
		{
			printf("%d ",iCnt);
		}
	}
}
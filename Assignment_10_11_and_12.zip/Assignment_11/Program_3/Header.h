#include<stdio.h>  
 
int Range(int,int);//Method Prototype
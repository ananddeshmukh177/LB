#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Range
//Parameters    : int
//Return Value  : int
//Description   : it is used to calculate addition of Range for given numbers
//Author        : Anand Manchakrao Deshmukh
//Date          : 07/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int Range(int iNo1,int iNo2)//Method Implimentation
{
	int iCnt = 0;
	int iSum = 0;
	if((iNo2 < iNo1) || (iNo1 < 0) || (iNo2 < 0))
	{
		return 0;
	}
	
	for(iCnt=iNo1 ; iCnt <= iNo2 ; iCnt++)
	{
		iSum = iSum+iCnt;
	}
	
	return iSum;
}
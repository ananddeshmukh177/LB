#include<stdio.h>         
void Display(int);//Method Prototype
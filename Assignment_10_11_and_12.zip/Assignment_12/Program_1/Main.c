/*
Problem Statement: Write a program which accept number from user and display below pattern. 
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue1 = 0;     //Local Variable

	printf("Enter a number:");   //Display Statement
	scanf("%d",&iValue1);  //Accept Statement
	Display(iValue1);     //Function Call
	
	return 0;           //return Succesfully
}
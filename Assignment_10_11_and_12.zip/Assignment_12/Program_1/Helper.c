#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Display
//Parameters    : int
//Return Value  : void
//Description   : it is used to calculate Range for given numbers
//Author        : Anand Manchakrao Deshmukh
//Date          : 07/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Display(int iNo1)//Method Implimentation
{
	int iCnt = 0;
	if(iNo1 < 0)
	{
		iNo1 = -iNo1;
	}
	for(iCnt=1 ; iCnt <= iNo1 ; iCnt++)
	{
		printf("* ");
	}
	for(iCnt=1 ; iCnt <= iNo1 ; iCnt++)
	{
		printf("# ");
	}
}
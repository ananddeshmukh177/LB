#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : OddFactorial
//Parameters    : int
//Return Value  : int
//Description   : it is used to find out odd factorial
//Author        : Anand Manchakrao Deshmukh
//Date          : 07/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int OddFactorial(int iNo)//Method Implimentation
{
	int iCnt = 0;
	int iFact = 1;
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= iNo ; iCnt++)
	{
		if((iCnt % 2) != 0)
		{
			iFact=iFact*iCnt;
		}
	}
	return iFact;
}
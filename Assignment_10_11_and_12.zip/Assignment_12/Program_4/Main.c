/*
Problem Statement:  Write a program to find odd factorial of given number. 
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iValue = 0;     //Local Variable
 	int iRet = 0;     //Local Variable

	printf("Enter a Number:");   //Display Statement
	scanf("%d",&iValue);  //Accept Statement
	iRet = OddFactorial(iValue);     //Function Call
	printf("Odd Factorial is :%d",iRet);
	
	return 0;           //return Succesfully
}
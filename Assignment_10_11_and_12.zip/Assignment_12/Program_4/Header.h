#include<stdio.h>         
int OddFactorial(int);//Method Prototype
#include<stdio.h>         
int EvenFactorial(int);//Method Prototype
#include<stdio.h>         
int DollerToINR(int);//Method Prototype
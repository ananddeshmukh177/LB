/*
Problem Statement:  Accept amount in US dollar and return its corresponding value in Indian currency.
Consider 1$ as 70 rupees.  
*/

#include"Header.h"            //Include header file

int main()                    //Entry Point Function
{
	int iDoller = 0;     //Local Variable
 	int iINR = 0;     //Local Variable

	printf("Enter amount in doller($):");   //Display Statement
	scanf("%d",&iDoller);  //Accept Statement
	iINR = DollerToINR(iDoller);     //Function Call
	printf("Amount in INR is :%d",iINR);
	
	return 0;           //return Succesfully
}
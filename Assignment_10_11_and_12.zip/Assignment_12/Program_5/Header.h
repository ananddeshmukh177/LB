#include<stdio.h>         
int DifferenceFactorial(int);//Method Prototype
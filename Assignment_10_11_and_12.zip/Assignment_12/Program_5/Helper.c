#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : DifferenceFactorial
//Parameters    : int
//Return Value  : int
//Description   : it is used to find Differnce between odd and even factorial
//Author        : Anand Manchakrao Deshmukh
//Date          : 07/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int DifferenceFactorial(int iNo)//Method Implimentation
{
	int iCnt = 0;
	int iFact1 = 1;
	int iFact2 = 1;

	if(iNo < 0)
	{
		iNo = -iNo;
	}
	for(iCnt = 1 ; iCnt <= iNo ; iCnt++)
	{
		if((iCnt % 2) == 0)
		{
			iFact1=iFact1*iCnt;
		}
	
		if((iCnt % 2) != 0)
		{
			iFact2=iFact2*iCnt;
		}
	}
	return iFact1-iFact2;
}
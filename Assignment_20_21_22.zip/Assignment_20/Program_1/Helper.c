#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CalculateBill
//Parameters    : int
//Return Value  : float
//Description   : it is used to CalculateBill .
//Author        : Anand Manchakrao Deshmukh
//Date          : 17/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

float CalculateBill(int iAmount)
{
	float fBill = 0.0f;
	if(iAmount <= 500)
	{
		fBill = iAmount;
		return fBill;
	}
	else if(iAmount > 500 && iAmount <= 1500)
	{
		fBill = iAmount-(iAmount*10/100);
		return fBill;
	}
	else
	{
		fBill = iAmount-(iAmount*15/100);
		return fBill;
	}
}

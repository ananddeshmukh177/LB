#include<stdio.h>         
float CalculateBill(int);
#include<stdio.h>         
long IncomeTax(int);
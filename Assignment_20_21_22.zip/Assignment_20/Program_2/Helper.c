#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : IncomeTax
//Parameters    : int
//Return Value  : float
//Description   : it is used to IncomeTax .
//Author        : Anand Manchakrao Deshmukh
//Date          : 17/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

long IncomeTax(int iAmount)
{
	long fBill = 0;
	long fBill2 = 0;
	long fBill3 = 0;
	if(iAmount < 500000)
	{
		fBill = 0;
		return fBill;
	}
	else if(iAmount >= 500000 && iAmount <= 1000000)
	{
		fBill = iAmount-500000;
		return (fBill*10/100);
	}
	else if(iAmount > 1000000 && iAmount <= 2000000)
	{
		fBill = iAmount-500000;
		fBill2 = ((fBill-500000));
		return (fBill2*20/100)+((fBill-fBill2)*10/100);
	}
	else
	{
		fBill = iAmount-500000;
		fBill2 = fBill-500000;
		fBill3 = fBill2-1000000;
		return (fBill3*30/100)+fBill2*20/100)+fBill*30/100);
	}
}

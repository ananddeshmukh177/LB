#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : SchoolFees
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate SchoolFees.
//Author        : Anand Manchakrao Deshmukh
//Date          : 17/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int TouristBill(int iKilometer)
{
	int iTotal1 = 0;
	int iTotal2 = 0;
	
	if(iKilometer <= 100)
	{
		return iKilometer*25;
	}
	else if(iKilometer > 100)
	{
		iTotal1 = (iKilometer-100);
		iTotal2 = iTotal1*15+(100*25);
		return iTotal2;
	}

}

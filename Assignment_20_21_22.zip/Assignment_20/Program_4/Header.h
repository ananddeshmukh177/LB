#include<stdio.h>         
int TouristBill(int);
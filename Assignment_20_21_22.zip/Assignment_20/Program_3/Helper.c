#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : SchoolFees
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate SchoolFees.
//Author        : Anand Manchakrao Deshmukh
//Date          : 17/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int SchoolFees(int iStandard)
{
	int fBill = 0;
	if(iStandard == 1)
	{
		fBill = 8900;
		return fBill;
	}
	else if(iStandard == 2)
	{
		fBill = 12790;
		return fBill;
	}
	else if(iStandard == 3)
	{
		fBill = 21000;
		return fBill;
	}
	else if(iStandard == 4)
	{
		fBill = 23450;
		return fBill;
	}
	else
	{
		return 0;
	}	
	
	

}

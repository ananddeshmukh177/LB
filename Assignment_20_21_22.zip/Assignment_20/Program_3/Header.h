#include<stdio.h>         
int SchoolFees(int);
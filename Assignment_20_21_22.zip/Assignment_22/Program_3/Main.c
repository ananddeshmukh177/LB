/*
Problem Statement: 
Accept N numbers from user check whether that numbers contains 11 in
it or not.
Input : N : 6
Elements : 85 66 11 80 93 88
Output : 11 is present
Input : N : 6
Elements : 85 66 3 80 93 88
Output : 11 is absent

*/

#include"Header.h"


int main()  //Execution Starts
{
	int iValue = 0;
	BOOL bRet = FALSE;
	int *ptr = NULL;  //Pointers Default Value
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue);                 ////Accept Array Size
	
	ptr = (int *)malloc(sizeof(int)*iValue); //Dynamic Memory Allocation
	
	if(ptr == NULL) //Check memory available or not
	{
		printf("Unable to allocte Memory");
		return -1;
	}
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		scanf("%d",&ptr[i]);         //Accept Array Elements 
	}
	
	printf("Array Elements are:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		printf("%d\n",ptr[i]);       //Display Array Elements
	}
	
	bRet = Check(ptr,iValue);   //Function call
	
	if(bRet == TRUE)
	{
		printf("Present");
	}
	else
	{
		printf("Absent");
	}
	
	free(ptr);    //Free Memory
	
	return 0;     //Successful Termination
	
}
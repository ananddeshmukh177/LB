#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Check
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate frequency Differnce of Even and Odd Elements
//Author        : Anand Manchakrao Deshmukh
//Date          : 18/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

BOOL Check(int *arr,int iSize)  //Array is pointer which stores base address;
{
	for(int i=0 ; i<iSize ; i++)
	{
		if( arr[i] == 11 )
		{	
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}

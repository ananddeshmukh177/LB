/*
Problem Statement: 

Accept N numbers from user and accept one another number as NO ,
return frequency of NO form it.
Input : N : 6
NO: 66
Elements : 85 66 3 66 93 88
Output : 2
Input : N : 6
NO: 12
Elements : 85 11 3 15 11 111
Output : 0
*/

#include"Header.h"


int main()  //Execution Starts
{
	int iValue = 0;
	int iValue2 = 0;
	int iRet = 0;
	int *ptr = NULL;  //Pointers Default Value
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue);                 ////Accept Array Size
	
	ptr = (int *)malloc(sizeof(int)*iValue); //Dynamic Memory Allocation
	
	if(ptr == NULL) //Check memory available or not
	{
		printf("Unable to allocte Memory");
		return -1;
	}
	
	printf("Enter Element to find frequency: ");
	scanf("%d",&iValue2);                
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		scanf("%d",&ptr[i]);         //Accept Array Elements 
	}
	
	printf("Array Elements are:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		printf("%d\n",ptr[i]);       //Display Array Elements
	}
	
	iRet = Frequency(ptr,iValue,iValue2);   //Function call
	
	printf("Frequency of given Element is :%d",iRet);
	
	
	free(ptr);    //Free Memory
	
	return 0;     //Successful Termination
	
}
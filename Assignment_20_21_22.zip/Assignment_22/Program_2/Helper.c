#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Frequency
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate frequency Differnce of Even and Odd Elements
//Author        : Anand Manchakrao Deshmukh
//Date          : 18/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int Frequency(int *arr,int iSize)  //Array is pointer which stores base address;
{
	int iCount1 = 0;
	int iCount2 = 0;
	for(int i=0 ; i<iSize ; i++)
	{
		if((arr[i]%2) == 0 )
		{	
			iCount1++;
		}
		else
		{
			iCount2++;
		}
	}
	
	return iCount1-iCount2;
}

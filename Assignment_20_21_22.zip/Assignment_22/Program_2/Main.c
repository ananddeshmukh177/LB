/*
Problem Statement: 

Accept N numbers from user and return difference between frequency of
even number and odd numbers.
Input : N : 7
Elements : 85 66 3 80 93 88 90
Output : 1 (4 -3)

*/

#include"Header.h"


int main()  //Execution Starts
{
	int iValue = 0;
	int iRet = 0;
	int *ptr = NULL;  //Pointers Default Value
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue);                 ////Accept Array Size
	
	ptr = (int *)malloc(sizeof(int)*iValue); //Dynamic Memory Allocation
	
	if(ptr == NULL) //Check memory available or not
	{
		printf("Unable to allocte Memory");
		return -1;
	}
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		scanf("%d",&ptr[i]);         //Accept Array Elements 
	}
	
	printf("Array Elements are:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		printf("%d\n",ptr[i]);       //Display Array Elements
	}
	
	iRet = Frequency(ptr,iValue);   //Function call
	
	printf("Frequency Difference :%d\n",iRet);
	
	free(ptr);    //Free Memory
	
	return 0;     //Successful Termination
	
}
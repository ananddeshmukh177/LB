#include<stdio.h>     //Header File 
#include<stdlib.h>    //Header File for malloc() calloc() realloc() free()  

//malloc() ->Used to allocate memory structure/User defined
//calloc() ->for array
//realloc() ->increase/decrease size of array
//free() ->delete memory   
      
int Frequency(int *,int);  //Function Prototype/Decleration
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Display
//Parameters    : int
//Return Value  : void
//Description   : it is used to Display multiples of 11
//Author        : Anand Manchakrao Deshmukh
//Date          : 18/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void Display(int *arr,int iSize)  //Array is pointer which stores base address;
{
	printf("Elements which are multiples of 11:\n");

	for(int i=0 ; i<iSize ; i++)
	{
		if((arr[i]%11) == 0 )
		{	
			printf("%d ",arr[i]);
		}
	}
}

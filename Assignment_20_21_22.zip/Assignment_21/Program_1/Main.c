/*
Problem Statement: 

Accept N numbers from user and return difference between summation
of even elements and summation of odd elements.

Input : N : 6
Elements : 85 66 3 80 93 88
Output : 53 (234 - 181)

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	int iRet = 0;
	int *ptr = NULL;
	
	printf("Enter Size of Elements: ");
	scanf("%d",&iValue);
	
	ptr = (int *)malloc(sizeof(int)*iValue);
	
	if(ptr == NULL)
	{
		printf("Unable to allocte Memory");
		return -1;
	}
	
	printf("Enter Array Elements:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		scanf("%d",&ptr[i]);
	}
	
	printf("Array Elements are:\n");
	for(int i=0 ; i<iValue ; i++)
	{
		printf("%d\n",ptr[i]);
	}
	
	iRet = Difference(ptr,iValue);
	
	printf("Difference between summation of odd and even numbers is: %d\n",iRet);
	
	free(ptr);
	
	return 0;
	
}
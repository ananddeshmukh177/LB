#include<stdio.h>   
#include<stdlib.h>         
      
int Difference(int *,int);
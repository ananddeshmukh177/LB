#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Difference
//Parameters    : int
//Return Value  : int
//Description   : it is used to Calculate Difference between summation of odd and even numbers .
//Author        : Anand Manchakrao Deshmukh
//Date          : 18/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

int Difference(int *arr,int iSize)  //Array is pointer which stores base address;
{
	int iSum = 0;
	for(int i=0 ; i<iSize ; i++)
	{
		if((arr[i]%2) == 0)
		{	
			iSum +=arr[i];
		}
		else
		{
			iSum -=arr[i];
		}
	}
	
	return iSum;
}

#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ToggleBit
//Parameters    : UINT
//Return Value  : UINT
//Description   : it is used to toggle 7th and 10th bit.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

UINT ToggleFirstFourBit(UINT iNo,UINT iPos1,UINT iPos2,UINT iPos3,UINT iPos4)
{	
	UINT iResult = 0;
	UINT iMask1 = 0X00000001;
	UINT iMask2 = 0X00000001;
	UINT iMask3 = 0X00000001;
	UINT iMask4 = 0X00000001;

	
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iPos1 > 32 || iPos1 < 1)
	{
		return POSITION_ERROR;
	}
	if(iPos2 > 32 || iPos2 < 1)
	{
		return POSITION_ERROR;
	}
	if(iPos3 > 32 || iPos3 < 1)
	{
		return POSITION_ERROR;
	}
	if(iPos4 > 32 || iPos4 < 1)
	{
		return POSITION_ERROR;
	}
	
	iMask1 = iMask1 << (iPos1-1);
	iMask2 = iMask2 << (iPos2-1);
	iMask3 = iMask3 << (iPos3-1);
	iMask4 = iMask4 << (iPos4-1);

	
	iNo = (iNo | iMask1);
	iNo = (iNo | iMask2);
	iNo = (iNo | iMask3);
	iResult = (iNo | iMask4);
	
	return iResult;
}

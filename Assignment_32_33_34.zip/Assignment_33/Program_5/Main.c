/*
Problem Statement: 

Write a program which accept one number from user and toggle 7th and
10th bit of that number. Return modified number.

Input : 137
Output : 713

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	UINT iPos1 = 0;
	UINT iPos2 = 0;
	UINT iPos3 = 0;
	UINT iPos4 = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	printf("Please Enter a First Position to toggle\nInput :");
	scanf("%d",&iPos1);
	
	printf("Please Enter a Second Position to toggle\nInput :");
	scanf("%d",&iPos2);
	
	printf("Please Enter a Third Position to toggle\nInput :");
	scanf("%d",&iPos3);
	
	printf("Please Enter a Fourth Position to toggle\nInput :");
	scanf("%d",&iPos4);
	
	
	iRet = ToggleFirstFourBit(iValue,iPos1,iPos2,iPos3,iPos4);
	
	printf("Number After Toggle of is First Four Bit :%d",iRet);

	return 0;
}
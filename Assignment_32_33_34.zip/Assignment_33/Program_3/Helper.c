#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ToggleBit
//Parameters    : UINT
//Return Value  : UINT
//Description   : it is used to toggle 7th bit.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

UINT ToggleBit(UINT iNo,UINT iPos)
{	
	UINT iResult = 0;
	UINT iMask = 0X00000001;

	
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iPos > 32 || iPos < 1)
	{
		return POSITION_ERROR;
	}
	
	iMask = iMask << (iPos-1);

	
	iResult = (iNo ^ iMask);
	
	return iResult;
}

/*
Problem Statement: 

Write a program which accept one number from user and toggle 7th bit of
that number. Return modified number.

Input : 137
Output : 201

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	UINT iPos = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	printf("Please Enter a Position to toggle\nInput :");
	scanf("%d",&iPos);
	
	iRet = ToggleBit(iValue,iPos);
	
	printf("Number After 7th Toggle is :%d",iRet);

	return 0;
}
#include<stdio.h>     //Header File 

typedef int BOOL;
typedef unsigned int UINT; 

#define POSITION_ERROR -1
#define TRUE 1
#define FALSE 0 

UINT ToggleBit(UINT iNo,UINT iPos);  //Function Prototype/Decleration
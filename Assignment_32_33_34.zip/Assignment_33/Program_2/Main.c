/*
Problem Statement: 

Write a program which accept one number from user and off 7th and 10th
bit of that number. Return modified number.

Input : 577
Output : 1

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	UINT iPos1 = 0;
	UINT iPos2 = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	
	printf("Please Enter a First Position\nInput :");
	scanf("%d",&iPos1);
	
	printf("Please Enter a Second Position\nInput :");
	scanf("%d",&iPos2);

	iRet = OffBit(iValue,iPos1,iPos2);
	
	printf("After 7th and 10th Bit is OFF :%d",iRet);

	return 0;
}
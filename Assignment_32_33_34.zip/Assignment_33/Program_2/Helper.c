#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : OffBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to make 7th bit is OFF if it is ON.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

UINT OffBit(UINT iNo,UINT iPos1,UINT iPos2)
{	
	UINT iResult = 0;
	UINT iMask1 = 0X00000001;
	UINT iMask2 = 0X00000001;

	
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iPos1 > 32 || iPos1 < 1)
	{
		return POSITION_ERROR;
	}
	
	if(iPos2 > 32 || iPos2 < 1)
	{
		return POSITION_ERROR;
	}
	
	iMask1 = iMask1 << (iPos1-1);
	iMask2 = iMask2 << (iPos2-1);

	
	iNo = ((iNo ^ iMask1));
	
	iResult = ((iNo ^ iMask2));
	
	return iResult;
}

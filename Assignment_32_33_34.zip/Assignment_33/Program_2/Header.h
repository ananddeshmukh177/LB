#include<stdio.h>     //Header File 

typedef int BOOL;
typedef unsigned int UINT; 

#define POSITION_ERROR -1
#define TRUE 1
#define FALSE 0 

UINT OffBit(UINT iNo,UINT iPos1,UINT iPos2);  //Function Prototype/Decleration
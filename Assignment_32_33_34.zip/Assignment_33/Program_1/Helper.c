#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : OffBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to make 7th bit is OFF if it is ON.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

UINT OffBit(UINT iNo,UINT iPos)
{	
	UINT iResult = 0;
	UINT iMask = 0X00000001;
	
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iPos > 32 || iPos < 1)
	{
		return POSITION_ERROR;
	}
	
	iMask = iMask << (iPos-1);
	
	iResult = (iNo ^ iMask);
	
	return iResult;
}

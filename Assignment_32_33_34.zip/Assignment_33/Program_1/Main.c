/*
Problem Statement: 

Write a program which accept one number from user and off 7th bit of that
number if it is on. Return modified number. 

Input : 79
Output : 15

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	UINT iPos = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	
	printf("Please Enter a Position\nInput :");
	scanf("%d",&iPos);

	iRet = OffBit(iValue,iPos);
	
	printf("After 7th Bit is OFF :%d",iRet);

	return 0;
}
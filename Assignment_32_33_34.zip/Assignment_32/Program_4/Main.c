/*
Problem Statement: 

Write a program which checks whether 7th & 8th & 9th bit is On or
OFF. 
 
0000 0000 0000 0000 0000 0001 1100 0000

Hexadecimal : 0X000001C0

//448 is SET

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	BOOL bRet = FALSE;
	//448 is SET
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	bRet = ChkBit(iValue);
	
	if(bRet == TRUE)
	{
		printf("Bit is ON/SET");
	}	
	else
	{
		printf("Bit is OFF/NOT SET");
	}
			
	return 0;
}
/*
Problem Statement: 

Write a program which checks whether 7th & 15th & 21st , 28th bit
is On or OFF.
 
0000 1000 0001 0000 0100 0000 0100 0000

Hexadecimal : 0X08104040

//135282752 is SET

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	BOOL bRet = FALSE;
	//135282752 is SET
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	bRet = ChkBit(iValue);
	
	if(bRet == TRUE)
	{
		printf("Bit is ON/SET");
	}	
	else
	{
		printf("Bit is OFF/NOT SET");
	}
			
	return 0;
}
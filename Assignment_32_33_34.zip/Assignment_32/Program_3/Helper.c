#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to check 7th & 15th & 21st , 28th bit is ON or OFF
//Author        : Anand Manchakrao Deshmukh
//Date          : 02/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//135282752 is SET

BOOL ChkBit(UINT iNo)
{	
	int iMask = 0X08104040;
	int iResult = 0;
	iResult = iNo & iMask;
	
	if(iResult == iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	
	
}

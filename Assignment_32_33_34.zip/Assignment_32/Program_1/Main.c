/*
Problem Statement: 

Write a program which checks whether 15th bit is On or OFF.

0000 0000 0000 0000 0100 0000 0000 0000

Hexadecimal : 0X00004000

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	BOOL bRet = FALSE;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	bRet = ChkBit(iValue);
	
	if(bRet == TRUE)
	{
		printf("Bit is ON/SET");
	}	
	else
	{
		printf("Bit is OFF/NOT SET");
	}
			
	return 0;
}
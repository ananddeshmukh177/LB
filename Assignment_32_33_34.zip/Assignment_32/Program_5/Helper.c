#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to check First(1) and Last(32) bit is ON or OFF
//Author        : Anand Manchakrao Deshmukh
//Date          : 02/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//-2147483647 is SET

BOOL ChkBit(UINT iNo)
{	
	int iMask = 0X80000001;
	int iResult = 0;
	iResult = iNo & iMask;
	
	if(iResult == iMask)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	
	
}

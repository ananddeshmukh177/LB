/*
Problem Statement: 

Write a program which checks whether first and last bit is On or
OFF. First bit means bit number 1 and last bit means bit number 32. 
 
1000 0000 0000 0000 0000 0000 0000 0001

Hexadecimal : 0X80000001

//-2147483647 is SET

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	BOOL bRet = FALSE;
	//-2147483647 is SET
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	bRet = ChkBit(iValue);
	
	if(bRet == TRUE)
	{
		printf("Bit is ON/SET");
	}	
	else
	{
		printf("Bit is OFF/NOT SET");
	}
			
	return 0;
}
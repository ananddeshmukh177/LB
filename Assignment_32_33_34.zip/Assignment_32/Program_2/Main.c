/*
Problem Statement: 

Write a program which checks whether 5th & 18th bit is On or OFF. 

0000 0000 0000 0010 0000 0000 0001 0000

Hexadecimal : 0X00020010

//131088 is SET

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	BOOL bRet = FALSE;
	//131088 is SET
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	bRet = ChkBit(iValue);
	
	if(bRet == TRUE)
	{
		printf("Bit is ON/SET");
	}	
	else
	{
		printf("Bit is OFF/NOT SET");
	}
			
	return 0;
}
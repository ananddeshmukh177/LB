/*
Problem Statement: 

Write a program which accept one number and position from user and off
that bit. Return modified number.

Input : 10 2
Output : 8
0X00800000

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	int iPos = 0;
	int iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	printf("Please Enter a Position\nInput :");
	scanf("%d",&iPos);

	iRet = Modify(iValue,iPos);
	
	printf("Modified Number is: %d",iRet);
	

	return 0;
}
#include<stdio.h>     //Header File 

typedef int BOOL;
typedef unsigned int UINT; 

#define TRUE 1
#define FALSE 0 

UINT Toggle(UINT);  //Function Prototype/Decleration


//1110  0000  0000

//0X00000e00
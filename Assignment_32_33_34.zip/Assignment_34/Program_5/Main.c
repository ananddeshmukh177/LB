/*
Problem Statement: 

Write a program which accept one number from user and toggle contents
of first and last nibble of the number. Return modified number. (Nibble is a
group of four bits)



*/

#include"Header.h"


int main()
{
	UINT iValue = 0;
	UINT iRet = 0;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);

	iRet = Toggle(iValue);
	
	printf("Modified Number is: %d",iRet);
	

	return 0;
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Modify
//Parameters    : UUINT
//Return Value  : BOOL
//Description   : it is used to toggle contents of first and last nibble of the number.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

/*	
	Input:  10
	
	Binary Input:  0000[Last Nibble]	0000	0000	0000	0000	0000	0000	1010[First Nibble]
	
	Binary Output: 1111 				0000	0000	0000	0000	0000	0000	0101
	
	Output: 4026531845
*/

UINT Toggle(UINT iNo)
{		
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	UINT iMask1 = 0X00000001;
	UINT iMask2 = 0X00000001;
	UINT iMask3 = 0X00000001;
	UINT iMask4 = 0X00000001;
	UINT iMask5 = 0X00000001;
	UINT iMask6 = 0X00000001;
	UINT iMask7 = 0X00000001;
	UINT iMask8 = 0X00000001;
	
	UINT iPos1 = 1;
	UINT iPos2 = 2;
	UINT iPos3 = 3;
	UINT iPos4 = 4;
	UINT iPos29 = 29;
	UINT iPos30 = 30;
	UINT iPos31 = 31;
	UINT iPos32 = 32;
	
	iMask1 = iMask1 << (iPos1-1);
	iMask2 = iMask2 << (iPos2-1);
	iMask3 = iMask3 << (iPos3-1);
	iMask4 = iMask4 << (iPos4-1);
	iMask5 = iMask5 << (iPos29-1);
	iMask6 = iMask6 << (iPos30-1);
	iMask7 = iMask7 << (iPos31-1);
	iMask8 = iMask8 << (iPos32-1);
	
	iNo = (iNo ^ iMask1);
		printf("%d\n",iNo);
	
	iNo = (iNo ^ iMask2);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask3);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask4);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask5);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask6);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask7);
		printf("%d\n",iNo);

	iNo = (iNo ^ iMask8);
		printf("%d\n",iNo);

	
	return iNo;

}

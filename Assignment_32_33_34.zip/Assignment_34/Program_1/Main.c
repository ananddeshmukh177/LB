/*
Problem Statement: 

Write a program which accept one number and position from user and
check whether bit at that position is on or off. If bit is one return TURE
otherwise return FALSE.

Input : 10 2

Output : TRUE

*/

#include"Header.h"


int main()
{
	int iValue = 0;
	int iPos = 0;
	BOOL bRet = FALSE;
	
	printf("Please Enter a Number\nInput :");
	scanf("%d",&iValue);
	
	printf("Please Enter a Position\nInput :");
	scanf("%d",&iPos);

	bRet = ChkBit(iValue,iPos);
	
	if(bRet == TRUE)
	{
		printf("Bit is Set");
	}
	else
	{
		printf("Bit is Not Set");
	}

	return 0;
}
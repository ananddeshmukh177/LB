#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkBit
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to check position from user and
//                check whether bit at that position is on or off.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL ChkBit(UINT iNo,UINT iPos)
{	
	int iMask = 0X00000000;
	int iPP = 0;
	int iRem = 0;
	
	while(iNo != 0)
	{
		iRem = iNo%2;
		iPP++;
		if(iPP == iPos)
		{
			break;
		}
		iNo = iNo/2;
	}
	
	if((iPos == iPP) && (iRem == 1))
	{
		return TRUE;
	}
	
	
	return FALSE;
}

#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Modify
//Parameters    : UINT
//Return Value  : BOOL
//Description   : it is used to check position from user and
//                check whether bit at that position is on or off.
//Author        : Anand Manchakrao Deshmukh
//Date          : 03/09/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int Modify(UINT iNo,UINT iPos)
{	
	int iResult = 0;
	int iMask = 0X00000001;
	
	if(iNo < 0)
	{
		iNo = -iNo;
	}
	
	if(iPos > 32 || iPos < 1)
	{
		return -1;
	}
	
	iMask = iMask << (iPos-1);
	
	iResult = (iNo | iMask);
	
	return iResult;

}

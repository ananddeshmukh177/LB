/*
    Problem statement : Write a program which accept number from user and return difference between
summation of even digits and summation of odd digits. 
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iAns= 0;
			
	printf("Enter  Numbers:");   //Display Statement
	scanf("%d",&iValue1);        //Accept input
	iAns=CountDiff(iValue1);          //Function Call
	printf("difference between summation of even digits and summation of odd digits:%d",iAns);
	return 0;                    //Successful Termination
}
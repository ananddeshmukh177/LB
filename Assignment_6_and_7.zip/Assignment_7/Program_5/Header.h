#include<stdio.h>


int CountDiff(int);
#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      CountDiff
// Parameters    :      int
// Return value  :      int
// Description   :      difference between summation of even digits and summation of odd digits
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

int CountDiff(int iNo1) //Method Implementation;
{
	int iDigit = 0;
	int iEvenSum = 0;
	int iOddSum = 0;

	if(iNo1 <  0)
	{
		iNo1=-iNo1;
	}
	while(iNo1!=0)
	{
		iDigit=iNo1%10;
		if((iDigit%2)==0)
		{
			iEvenSum=iEvenSum+iDigit;
		}
		if((iDigit%2)!=0)
		{
			iOddSum=iOddSum+iDigit;
		}
		iNo1=iNo1/10;
	}
	
	return iEvenSum-iOddSum;
	
}
/*
    Problem statement : Write a program which accept number from user and count numbers in between 3 and 7.
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	int iAns= 0;
			
	printf("Enter  Numbers:");   //Display Statement
	scanf("%d",&iValue1);        //Accept input
	iAns=CountRange(iValue1);          //Function Call
	printf("count numbers in between 3 and 7:%d",iAns);
	return 0;                    //Successful Termination
}
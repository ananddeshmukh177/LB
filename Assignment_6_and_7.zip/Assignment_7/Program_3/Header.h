#include<stdio.h>


int CountRange(int);
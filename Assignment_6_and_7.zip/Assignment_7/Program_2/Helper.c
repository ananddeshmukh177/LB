#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      CountOdd
// Parameters    :      int
// Return value  :      int
// Description   :      it Display count odd
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

int CountOdd(int iNo1) //Method Implementation;
{
	int iDigit = 0;
	int cnt =0;
	if(iNo1 <  0)
	{
		iNo1=-iNo1;
	}
	while(iNo1!=0)
	{
		iDigit=iNo1%10;
		if((iDigit % 2) != 0)
		{
			cnt++;
		}
		iNo1=iNo1/10;
	}
	
	return cnt;
	
}
#include<stdio.h>


int CountOdd(int);
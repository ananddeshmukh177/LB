#include<stdio.h>


int CountEven(int);
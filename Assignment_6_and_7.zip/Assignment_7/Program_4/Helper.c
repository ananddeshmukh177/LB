#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      MultDigits
// Parameters    :      int
// Return value  :      int
// Description   :      Multiplication of digits
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

int MultDigits(int iNo1) //Method Implementation;
{
	int iDigit = 0;
	int iMult =1;
	if(iNo1 <  0)
	{
		iNo1=-iNo1;
	}
	while(iNo1!=0)
	{
		iDigit=iNo1%10;
		iMult=iMult*iDigit;
		iNo1=iNo1/10;
	}
	
	return iMult;
	
}
#include<stdio.h>


int MultDigits(int);
/*
    Problem statement : Write a program which accept number from user and display its digits in reverse
order. 
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
			
	printf("Enter  Numbers:"); //Display Statement
	scanf("%d",&iValue1);       //Accept input
	DisplayDigit(iValue1);          //Function Call
	
	return 0;                 //Successful Termination
}
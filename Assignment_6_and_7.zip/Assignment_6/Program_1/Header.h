#include<stdio.h>

void DisplayDigit(int);
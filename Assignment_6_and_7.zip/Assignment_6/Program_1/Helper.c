#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      DisplayDigit
// Parameters    :      int
// Return value  :      void
// Description   :      it Display Digits
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

void DisplayDigit(int iNo1) //Method Implementation;
{
	int iDigit = 0;
	int cnt =0;
	if(iNo1 <  0)
	{
		iNo1=-iNo1;
	}
	while(iNo1!=0)
	{
		iDigit=iNo1%10;
		printf("%d",iDigit);
		iNo1=iNo1/10;
	}
}
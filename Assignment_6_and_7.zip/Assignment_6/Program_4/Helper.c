#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

//////////////////////////////////////////////////////////////
//
// Function name :      CountFour
// Parameters    :      int
// Return value  :      int
// Description   :      it Display count of twos
// Author        :      Anand Manchakrao Deshmukh
// Date          :      04 August 2020
//
//////////////////////////////////////////////////////////////

int CountFour(int iNo1) //Method Implementation;
{
	int iDigit = 0;
	int cnt =0;
	if(iNo1 <  0)
	{
		iNo1=-iNo1;
	}
	while(iNo1!=0)
	{
		iDigit=iNo1%10;
		if(iDigit==4)
		{
			cnt++;
		}
		iNo1=iNo1/10;
	}
	
	return cnt;
	
}
#include<stdio.h>


int CountFour(int);
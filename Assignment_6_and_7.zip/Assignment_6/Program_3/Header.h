#include<stdio.h>


int CountTwo(int);
#include<stdio.h>
typedef int BOOLEAN;
#define TRUE 1
#define FALSE 0

BOOLEAN ChkZero(int);
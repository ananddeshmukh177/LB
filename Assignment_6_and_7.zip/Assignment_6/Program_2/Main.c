/*
    Problem statement : Write a program which accept number from user and check whether it contains 0
in it or not.
order. 
*/

#include "Header.h"           //Including Custom Header File; 
                              //this header file is searched in current location;

int main()                    //Entry Point Function
{
	int iValue1 = 0;
	BOOLEAN iAns=FALSE;
			
	printf("Enter  Numbers:"); //Display Statement
	scanf("%d",&iValue1);       //Accept input
	iAns=ChkZero(iValue1);          //Function Call
	if(iAns == TRUE)
	{
		printf("it contains zero");
	}
	else
	{
		printf("there is no zero");

	}
	return 0;                 //Successful Termination
}
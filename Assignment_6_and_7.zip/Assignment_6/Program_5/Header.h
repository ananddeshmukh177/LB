#include<stdio.h>


int Count(int);
/*
Write a program which return smallest element from singly linear linked list.

Function Prototype :int Minimum( PNODE Head);

Input linked list : |110|->|230|->|20|->|240|->|640|

Output : 20

*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

int  MinElements(PNODE Head)
{
	int iMin = Head->data;
	
    while(Head != NULL)
	{
		if((Head->data) < iMin)
		{
			iMin = Head->data;
		}
		Head = Head->next;
	}
	
	return iMin;
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 int iNo;
 int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 51);
 InsertFirst(&First, 21);
 InsertFirst(&First, 11);

 //printf("Element an Element to Find \nInput :");
 //scanf("%d",&iNo);
 
 iRet = MinElements(First);
 
 printf("Minimum Elements : %d",iRet);
 // Call all functions for below problem statements.
 return 0;
} 
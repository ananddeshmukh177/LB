/*
Write a program which search first occurrence of particular element from
singly linear linked list.Function should return position at which element is found.

Function Prototype :int SearchFirstOcc( PNODE Head , int no );

Input linked list : |10|->|20|->|30|->|40|->|50|->|30|->|70|

Input element : 30

Output : 3 
*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

int  SearchFirstOcc(PNODE Head, int no)
{
	int iCnt = 0;
    while(Head != NULL)
	{
		iCnt++;
		if(Head->data == no)
		{
			break;
		}
		Head = Head->next;
	}
	
	if(Head == NULL)
	{
		return 0;
	}
	
	return iCnt;
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 int iNo;
 int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 51);
 InsertFirst(&First, 21);
 InsertFirst(&First, 11);

 printf("Element an Element to Find \nInput :");
 scanf("%d",&iNo);
 
 iRet = SearchFirstOcc(First,iNo);
 
 printf("Element is Found at Index : %d",iRet);
 // Call all functions for below problem statements.
 return 0;
} 
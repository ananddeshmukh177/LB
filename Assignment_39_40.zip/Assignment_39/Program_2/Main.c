/*
Write a program which search last occurrence of particular element from
singly linear linked list.Function should return position at which element is found.

Function Prototype :int SearchLastOcc( PNODE Head , int no );

Input linked list : |10|->|20|->|30|->|40|->|50|->|30|->|70|

Input element : 30

Output : 3 
*/

#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * prev;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
	newn-> prev = NULL; // Initialise pointer

    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name    : LastOcc
// Description      : Used to Last Occ of element in a Linked List
// Parameters       : First pointer & data of node
// Return Value     : int
//
///////////////////////////////////////////////////////////////////


int  SearchLastOcc(PNODE Head, int no)
{
	int iCnt = 0;
	int j = 0;
	while(Head != NULL)
	{
		j++;
		if(Head->data == no)
		{
			iCnt = j;
		}
		printf("\nInside First While :%d ",j);

		Head = Head->next;
	}
	printf("\nOutside First While :%d ",j);
   
	if(Head == NULL && iCnt == 0)
	{
		return 0;
	}
	return iCnt;
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 int iNo;
 int iRet = 0;
 InsertFirst(&First, 20);
 InsertFirst(&First, 50);
 InsertFirst(&First, 40);
 InsertFirst(&First, 30);
 InsertFirst(&First, 20);

 printf("Element an Element to Find \nInput :");
 scanf("%d",&iNo);
 
 iRet = SearchLastOcc(First,iNo);
 
 printf("Element is Found at Index : %d",iRet);
 // Call all functions for below problem statements.
 return 0;
} 
/*
Write a program which returns addition of all element from singly linear
linked list.

Function Prototype :int Addition( PNODE Head);

Input linked list : |10|->|20|->|30|->|40|

Output : 100
*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

int  SumOfElements(PNODE Head)
{
	int iSum = 0;
    while(Head != NULL)
	{
		iSum += Head->data;
		Head = Head->next;
	}
	
	return iSum;
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 int iNo;
 int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 51);
 InsertFirst(&First, 21);
 InsertFirst(&First, 11);

 //printf("Element an Element to Find \nInput :");
 //scanf("%d",&iNo);
 
 iRet = SumOfElements(First);
 
 printf("Sum of Elements : %d",iRet);
 // Call all functions for below problem statements.
 return 0;
} 
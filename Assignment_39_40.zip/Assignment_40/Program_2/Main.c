/*
Write a program which displays all elements which are prime from singly linear linked list.

Function Prototype :int DisplayPrime( PNODE Head);

Input linked list : |11|->|20|->|17|->|41|->|22|->|89|

Output : 11 17 41 89

*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

void  DisplayPrime(PNODE Head)
{
	int iCnt = 0;
	int No = 0;
	printf("Prime Numbers are :\n");
	while(Head != NULL)
	{
		No = Head->data;
		iCnt = 0;
		for(int i = 1 ; i<=(No/2) ; i++)
		{		if((No % i) == 0)
				{
					iCnt += i;
				}
		}
		
		if(iCnt  == 1)
		{
			printf("%d\n",No);
		}
		
		Head = Head->next;
	}
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 //int iNo;
 //int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 17);
 InsertFirst(&First, 41);
 InsertFirst(&First, 11);
 InsertFirst(&First, 28);
 InsertFirst(&First, 6);

 
 DisplayPrime(First);

 /*printf("Element an Element to Find \nInput :");
 scanf("%d",&iNo);
 
 iRet = SearchFirstOcc(First,iNo);
 
 printf("Element is Found at Index : %d",iRet);*/
 // Call all functions for below problem statements.
 return 0;
} 
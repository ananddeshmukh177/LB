/*
Write a program which return second maximum element from singly linear linked list.

Function Prototype :int SecMaximum( PNODE Head);

Input linked list : |110|->|230|->|320|->|240|

Output : 240

*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

int  SecMaximum(PNODE Head)
{
	int iMax1 = 0;
	int iMax2 = 0;
	int No = 0;
	while(Head != NULL)
	{
		No = Head->data;
		if((No > iMax1))
		{
			iMax2 = iMax1;
			iMax1 = No;
		}
		
		Head = Head->next;
	}
	
	return iMax2;
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 //int iNo;
 int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 17);
 InsertFirst(&First, 41);
 InsertFirst(&First, 11);
 InsertFirst(&First, 28);
 InsertFirst(&First, 6);

 
  iRet = SecMaximum(First);
  printf("Second Maximum ELements is : %d",iRet);
 /*printf("Element an Element to Find \nInput :");
 scanf("%d",&iNo);
 
 iRet = SearchFirstOcc(First,iNo);
 
*/
 // Call all functions for below problem statements.
 return 0;
} 
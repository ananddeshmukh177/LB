/*
Write a program which display addition of digits of element from singly linear linked list.

Function Prototype :int SumDigit( PNODE Head);

Input linked list : |110|->|230|->|20|->|240|->|640|

Output : 2 5 2 6 10

*/
#include<stdio.h>
#include<stdlib.h>

struct Node     // Structre Defination
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

/*----------------------------------------------------------
            Old Name                    New Name
 ----------------------------------------------------------
            struct Node                     NODE
            struct Node *                  PNODE
            struct Node **                PPNODE
 ----------------------------------------------------------*/

///////////////////////////////////////////////////////////////////
//
// Function name  : InsertFirst
// Description       : Used to insert at first position of Linked List
// Parameters       : Addreass of First pointer & data of node
// Return Value     : void
//
///////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head, int no)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // Allocate memory
    newn-> data = no;   // Iniitialise data
    newn-> next = NULL; // Initialise pointer
    
    if(*Head == NULL) // Linkedlist is empty
    {
        *Head = newn;
    }
    else  // LL contains atleast one node
    {
        newn -> next = *Head;
        *Head = newn;
    }
}


/*------------------------------------------*/

void  SumDigit(PNODE Head)
{
	int iRem = 0;
	int iSum = 0;
	int No = 0;
	printf("Addition of Digits: \n");
	while(Head != NULL)
	{
		No = Head->data;
		iSum = 0;
		while(No != 0)
		{
			iRem = No%10;
			iSum += iRem;
			No = No/10;
		}	
		
		printf("%d ",iSum);
		
		Head = Head->next;

	}
}


/*------------------------------------------*/

int main()
{
 PNODE First = NULL;
 //int iNo;
 //int iRet = 0;
 InsertFirst(&First, 101);
 InsertFirst(&First, 17);
 InsertFirst(&First, 41);
 InsertFirst(&First, 11);
 InsertFirst(&First, 28);
 InsertFirst(&First, 6);

 
 SumDigit(First);
  //printf("Second Maximum ELements is : %d",iRet);
 /*printf("Element an Element to Find \nInput :");
 scanf("%d",&iNo);
 
 iRet = SearchFirstOcc(First,iNo);
 
*/
 // Call all functions for below problem statements.
 return 0;
} 
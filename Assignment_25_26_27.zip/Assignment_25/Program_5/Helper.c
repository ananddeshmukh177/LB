#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : DisplaySchedule
//Parameters    : char
//Return Value  : void
//Description   : it is used to class divisions exam schedule.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void DisplaySchedule(char cValue)
{	
    if((cValue == 'a' || cValue <= 'A'))
	{
		printf("Your exam at 7 AM");
	}
	else if((cValue == 'b' || cValue <= 'B'))
	{
		printf("Your exam at 8.30 AM");
	}
	else if((cValue == 'c' || cValue <= 'C'))
	{
		printf("Your exam at 9.20 AM");
	}
	else if((cValue == 'd' || cValue <= 'D'))
	{
		printf("Your exam at 10.30 AM");
	}
	else
	{
		printf("Division Not Found");
	}

}

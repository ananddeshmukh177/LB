/*
Problem Statement: 

Accept Character from user and check whether it is digit or not
(0-9).
Input : 7
Output : TRUE
Input : d
Output : FALSE  
 
*/

#include"Header.h"


int main()
{
	char cValue = '\0';
	BOOL bRet = FALSE;
	
	printf("Check an  digit or not:");
	scanf("%c",&cValue);
	
	bRet = ChkDigit(cValue);
	
	if(bRet == TRUE)
	{
		printf("TRUE");
	}
	else
	{
		printf("FALSE");
	}
	
	return 0;
}
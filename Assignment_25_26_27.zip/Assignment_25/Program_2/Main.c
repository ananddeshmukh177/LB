/*
Problem Statement: 

Accept Character from user and check whether it is capital or not
(A-Z).
Input : F
Output : TRUE
Input : d
Output : FALSE 
 
*/

#include"Header.h"


int main()
{
	char cValue = '\0';
	BOOL bRet = FALSE;
	
	printf("Check an Alphabate Capital or not:");
	scanf("%c",&cValue);
	
	bRet = ChkCapital(cValue);
	
	if(bRet == TRUE)
	{
		printf("TRUE");
	}
	else
	{
		printf("FALSE");
	}
	
	return 0;
}
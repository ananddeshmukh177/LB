/*
Problem Statement: 

Accept Character from user and check whether it is small case or
not (a-z).
Input : g
Output : TRUE
Input : D
Output : FALSE  
 
*/

#include"Header.h"


int main()
{
	char cValue = '\0';
	BOOL bRet = FALSE;
	
	printf("Check an Alphabate small or not:");
	scanf("%c",&cValue);
	
	bRet = ChkSmall(cValue);
	
	if(bRet == TRUE)
	{
		printf("TRUE");
	}
	else
	{
		printf("FALSE");
	}
	
	return 0;
}
#include<stdio.h>     //Header File 
//typedef int BOOL;
//#define TRUE 1
//#define FALSE 0    
void Display(char);  //Function Prototype/Decleration
/*
Problem Statement: 

Write a program which displays ASCII table. Table contains symbol,
Decimal, Hexadecimal and Octal representation of every member from
0 to 255.

*/

#include"Header.h"


int main()
{
	char cValue = '\0';
	
	printf("Please Enter a Special Symbol\nInput :");
	scanf("%c",&cValue);
	
	Display(cValue);
	
	return 0;
}
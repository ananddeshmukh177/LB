#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Display
//Parameters    : char
//Return Value  : void
//Description   : it is used to Display print all the characters.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void Display(char cValue)
{	
	printf("Output :");
    if((cValue >= 'a' && cValue <= 'z'))
	{
		for(int i =(123-(123-cValue)) ; i >= 97 ; i--)
		{
			printf("%c ",i);
		}
	}
	else if((cValue >= 'A' && cValue <= 'Z'))
	{
		for(int i =65-(65-cValue) ; i <= 90 ; i++)
		{
			printf("%c ",i);
		}
    }
	else
	{
		return;
	}
}

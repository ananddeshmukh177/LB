#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Display
//Parameters    : char
//Return Value  : void
//Description   : it is used to Display corresponding value.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void Display(char cValue)
{	
    if((cValue >= 'a' && cValue <= 'z'))
	{
		printf("%c",(cValue-32));
	}
	else if((cValue >= 'A' && cValue <= 'Z'))
	{
		printf("%c",(cValue+32));
	}
	else
	{
		printf("%c",cValue);
	}

}

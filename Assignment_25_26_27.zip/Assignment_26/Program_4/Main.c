/*
Problem Statement: 

Accept Character from user and check whether it is special symbol
or not (!, @, #, $, %, ^, &, *).
Input : %
Output : TRUE
Input : d
Output : FALSE

*/

#include"Header.h"


int main()
{
	char cValue = '\0';
	BOOL bRet = FALSE;
	
	printf("Please Enter a Special Symbol\nInput :");
	scanf("%c",&cValue);
	
	bRet = Display(cValue);
	
	if(bRet == TRUE)
	{
		printf("TRUE");
	}	
	else
	{
		printf("FALSE");
	}
	
	return 0;
}
#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Display
//Parameters    : char
//Return Value  : BOOL
//Description   : it is used to Display print all the characters.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

BOOL Display(char cValue)
{	
	printf("Output :");
	//(!, @, #, $, %, ^, &, *)
    if((cValue == '!' || cValue == '@' || cValue == '#'|| cValue == '$'|| 
		cValue == '%'|| cValue == '^'|| cValue == '&'|| cValue == '*'))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

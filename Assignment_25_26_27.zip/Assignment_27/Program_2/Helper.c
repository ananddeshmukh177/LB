#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CountSmall
//Parameters    : char
//Return Value  : int
//Description   : it is used to calculate small alphabate.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int CountSmall(char *cPtr)
{	
	int iCnt = 0;
	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	while(*cPtr != '\0')
	{
		if(*cPtr >= 'a' && *cPtr <= 'z')
		{
			iCnt++;
		}
		cPtr++;
	}
	
	return iCnt;
}

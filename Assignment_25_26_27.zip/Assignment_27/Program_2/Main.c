/*
Problem Statement: 

Write a program which accept string from user and count number of
Small characters.
Input : “Marvellous”
Output : 9

*/

#include"Header.h"


int main()
{
	char arr[20];
	int iRet = 0;
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	iRet = CountSmall(arr);
	
	printf("number of small characters: %d",iRet);
	
	return 0;
}
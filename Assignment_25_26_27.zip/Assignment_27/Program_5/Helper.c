#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Reverse
//Parameters    : char
//Return Value  : void
//Description   : it is used to Display Reverse string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 20/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void Reverse(char cPtr[])
{	
	int i = 0;
	int j = strlen(cPtr)-1;
	
	if(cPtr == NULL)
	{
		return;
	}
	
	while(i < j)
	{
		int temp = cPtr[i];
		cPtr[i] = cPtr[j];
		cPtr[j] = temp;
		
		i++;
		j--;
	}
	
	printf("%s",cPtr);
}

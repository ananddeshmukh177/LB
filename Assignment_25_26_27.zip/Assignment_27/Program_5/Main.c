/*
Problem Statement: 

Write a program which accept string from user and display it in reverse order.
Input  : “MarvellouS”
Output : “SuollevraM”

*/

#include"Header.h"


int main()
{
	char arr[20];
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	Reverse(arr);
	
	return 0;
}
/*
Problem Statement: 

Write a program which accept string from user and return
difference between frequency of small characters and frequency of
capital characters.
Input : “MarvellouS”
Output : 6 (8-2)

*/

#include"Header.h"


int main()
{
	char arr[20];
	int iRet = 0;
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	iRet = Difference(arr);
	
	printf("Difference between number of small and capital characters: %d",iRet);
	
	return 0;
}
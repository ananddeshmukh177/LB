#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : Difference
//Parameters    : char
//Return Value  : int
//Description   : it is used to calculate Difference between number of small and Capital alphabate.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int Difference(char *cPtr)
{	
	int iCnt1 = 0;
	int iCnt2 = 0;

	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	while(*cPtr != '\0')
	{
		if(*cPtr >= 'a' && *cPtr <= 'z')
		{
			iCnt1++;
		}
		if(*cPtr >= 'A' && *cPtr <= 'Z')
		{
			iCnt2++;
		}
		cPtr++;
	}
	
	return iCnt1-iCnt2;
}

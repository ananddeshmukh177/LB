#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : CountCapital
//Parameters    : char
//Return Value  : int
//Description   : it is used to calculate capital alphabate.
//Author        : Anand Manchakrao Deshmukh
//Date          : 19/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int CountCapital(char *cPtr)
{	
	int iCnt = 0;
	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	
	while(*cPtr != '\0')
	{
		if(*cPtr >= 'A' && *cPtr <= 'Z')
		{
			iCnt++;
		}
		cPtr++;
	}
	
	return iCnt;
}

/*
Problem Statement: 

Write a program which accept string from user and count number of
capital characters.
Input : “Marvellous Multi OS”
Output : 4

*/

#include"Header.h"


int main()
{
	char arr[20];
	int iRet = 0;
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	iRet = CountCapital(arr);
	
	printf("number of capital characters: %d",iRet);
	
	return 0;
}
/*
Problem Statement: 

Write a program which accept string from user and check whether
it contains vowels in it or not.
Input : “marvellous”
Output : TRUE
Input : “Demo”
Output : TRUE
Input : “xyz”
Output : FALSE

*/

#include"Header.h"


int main()
{
	char arr[20];
	BOOL bRet = FALSE;
	
	printf("Please Enter a String\nInput :");
	scanf("%[^'\n']s",arr);
	
	bRet = ChkVowel(arr);
	
	if(bRet == TRUE)
	{
		printf("Contains Vowel");
	}
	else
	{
		printf("There is No Vowel");
	}
	
	return 0;
}
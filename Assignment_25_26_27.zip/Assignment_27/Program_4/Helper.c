#include"Header.h"//Include Header File


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//
//Function Name : ChkVowel
//Parameters    : char
//Return Value  : BOOL
//Description   : it is used to Check Vowels in a string.
//Author        : Anand Manchakrao Deshmukh
//Date          : 20/08/2020
//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

int ChkVowel(char *cPtr)
{	
	int iCnt = 0;

	if(cPtr == NULL)
	{
		return MEMORY_ERROR;
	}
	while(*cPtr != '\0')
	{
		if((*cPtr == 'a' || *cPtr == 'e' || *cPtr == 'i' || *cPtr == 'o' || *cPtr == 'u')
			|| (*cPtr == 'A' || *cPtr == 'E' || *cPtr == 'I' || *cPtr == 'O' || *cPtr == 'U'))
		{
			iCnt++;
		}
		
		cPtr++;
	}
	
	if(iCnt > 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

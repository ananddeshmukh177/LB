#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
};

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

///////////////////////////////////////////////////////////////////////////////
//
//Function   : Count
//parameter  : PPNODE,PPNODE
//return     : int
//Description: Used to Count Linked List Elements.
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

int Count(PNODE Head,PNODE Tail)
{
	int iCnt = 0;
	if((Head == NULL) || (Tail == NULL))
	{
		return 0;
	}

	do
	{
		iCnt++;
		Head = Head->next;
	}
	while(Head != Tail->next);
	return iCnt;
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : Display
//parameter  : PPNODE,PPNODE
//return     : void
//Description: Used to Display Linked List
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void Display(PNODE Head,PNODE Tail)
{
	if((Head == NULL) || (Tail == NULL))
	{
		return;
	}

	do
	{
		printf("<-|%d|->",Head->data);
		Head = Head->next;
	}
	while(Head != Tail->next);
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : InsertFirst
//parameter  : PPNODE,PPNODE,int
//return     : void
//Description: Used to insert Node at First Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head,PPNODE Tail,int iValue)
{
		PNODE newn = NULL;
		newn = (PNODE)malloc(sizeof(NODE));
		newn->data = iValue;
		newn->next = NULL;
		newn->prev = NULL;
		
		if(((*Head) == NULL) && ((*Tail) == NULL))
		{
			*Head = newn;
			*Tail = newn;
		}
		else
		{
			newn->next = *Head;
			(*Head)->prev = newn;
			*Head = (*Head)->prev;
		}
		
		(*Head)->prev = (*Tail);
		(*Tail)->next = (*Head);

}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : InsertLast
//parameter  : PPNODE,PPNODE,int
//return     : void
//Description: Used to insert Node at Last Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void InsertLast(PPNODE Head,PPNODE Tail,int iValue)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	newn->data = iValue;
	newn->next = NULL;
	newn->prev = NULL;
	
	if(*Head ==  NULL && *Tail == NULL)
	{
		*Head = newn;
		*Tail = newn;
	}
	else
	{
		(*Tail)->next = newn;
		 newn->prev = *Tail;
		 *Tail = (*Tail)->next;
	}
	(*Head)->prev = *Tail;
	(*Tail)->next = *Head;
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : InsertAtPosition
//parameter  : PPNODE,PPNODE,int
//return     : void
//Description: Used to insert Node at Given Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void InsertAtPosition(PPNODE Head,PPNODE Tail,int iValue,int iPos)
{
	PNODE newn = NULL;
	PNODE temp = *Head;
	newn = (PNODE)malloc(sizeof(NODE));
	newn->data = iValue;
	newn->next = NULL;
	newn->prev = NULL;
	
	int iSize = Count(*Head,*Tail);
	
	if(iPos < 1 || iPos > iSize+1)
	{
		return;
	}
	
	if(iPos == 1)
	{
		InsertFirst(Head,Tail,iValue);
	}
	else if(iPos == iSize+1)
	{
		InsertLast(Head,Tail,iValue);
	}
	else
	{
		for(int i = 1 ; i < iPos-1 ; i++)
		{
			temp = temp->next;
		}
		newn->next = temp->next;
		temp->next->prev = newn;
		temp->next = newn;
		newn->prev = temp;
		
		
		(*Head)->prev = *Tail;
		(*Tail)->next = *Head;
	}
	
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : DeleteFirst
//parameter  : PPNODE,PPNODE
//return     : void
//Description: Used to Delete Node at First Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void DeleteFirst(PPNODE Head,PPNODE Tail)
{
	PNODE temp = *Head;
	
	if((*Head == NULL) && (*Tail == NULL))
	{
		return;
	}
	else if((*Head)->next == NULL)
	{
		free(*Head);
		*Head = NULL;
	}
	else
	{
		*Head = temp->next;
		free(temp);

	}
	
	(*Head)->prev = *Tail;
    (*Tail)->next = *Head;	
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : DeleteLast
//parameter  : PPNODE,PPNODE
//return     : void
//Description: Used to Delete Node at Last Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void DeleteLast(PPNODE Head,PPNODE Tail)
{
	PNODE temp = *Tail;
	if((*Head == NULL) && (*Tail == NULL))
	{
		return;
	}
	else if((*Head)->next == NULL)
	{
		free(*Head);
		*Head = NULL;
	}
	else
	{
		*Tail = temp->prev;
		free(temp);
	}
	
	(*Head)->prev = *Tail;
	(*Tail)->next = *Head;
}

///////////////////////////////////////////////////////////////////////////////
//
//Function   : DeleteAtPosition
//parameter  : PPNODE,PPNODE
//return     : void
//Description: Used to Delete Node at Given Position
//Author     : Anand Deshmukh
//Date       : 11/09/2020
//
///////////////////////////////////////////////////////////////////////////////

void DeleteAtPosition(PPNODE Head,PPNODE Tail,int iPos)
{
	PNODE temp = *Head;
	int iSize = Count(*Head,*Tail);
	if((*Head == NULL) && (*Tail == NULL))
	{
		return;
	}
	
	if(iPos < 1 || iPos > iSize)
	{
		return;
	}
	
	if(iPos == 1)
	{
		DeleteFirst(Head,Tail);
	}
	else if(iPos == iSize)
	{
		DeleteLast(Head,Tail);
	}
	else
	{
		for(int i = 1 ; i < iPos-1 ; i++)
		{
			temp = temp->next;
		}
		PNODE temp2 = temp->next;
		temp2->next->prev = temp;
		temp->next = temp2->next;
		free(temp2);
		
		
		
		(*Head)->prev = *Tail;
		(*Tail)->next = *Head;
	}
}

int main()
{
	PNODE First = NULL;
	PNODE Last = NULL;//New
	int iRet = 0;
	int iNo = 0;
	int no = 0;
	int iPos = 0;

	while(1)
	{
		printf("\n*********MENU*********\n");
		printf("\n1.Insert At First");
		printf("\n2.Insert At Last");
		printf("\n3.Insert At Position");
		printf("\n4.Delete At First");
		printf("\n5.Delete At Last");
		printf("\n6.Delete At Position");
		printf("\n7.Count of Linked List");
		printf("\n8.Display Linked List\n");
		printf("\nEnter Your Choice :\n");
		int choice = 0;
		scanf("%d",&choice);

		switch(choice)
		{
					case 1 :
					printf("Enter a Number:");
					scanf("%d",&iNo);
					InsertFirst(&First,&Last,iNo);
					Display(First,Last);
					break;
					case 2 :
					printf("Enter a Number:");
					scanf("%d",&iNo);
					InsertLast(&First,&Last,iNo);
					Display(First,Last);
					break;
					case 3 :
					printf("Enter a Number:");
					scanf("%d",&iNo);
					printf("Enter a Position:");
					scanf("%d",&iPos);
					InsertAtPosition(&First,&Last,iNo,iPos);
					Display(First,Last);
					break;
					case 4 :
					DeleteFirst(&First,&Last);
					Display(First,Last);
					break;
					case 5 :
					DeleteLast(&First,&Last);
					Display(First,Last);
					break;
					case 6 :
					printf("Enter a Position:");
					scanf("%d",&iPos);
					DeleteAtPosition(&First,&Last,iPos);
					Display(First,Last);
					break;
					case 7 :
					iRet = Count(First,Last);
					printf("Count of Linked List:%d",iRet);
					break;
					case 8 :
					Display(First,Last);
					break;
					default :
					printf("Invalid Choice:");
					break;

		}
		
		printf("\nDo you want to Continue Press 1 otherwise Press 0");
		scanf("%d",&no);
		if(no == 0)
		{
			break;
		}
	}
	
	return 0;
}
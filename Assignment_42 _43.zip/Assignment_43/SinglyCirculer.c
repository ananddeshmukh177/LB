#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node* next;
};

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

/////////////////////////////////////////////////////////////////////////////
//
//Function    : Count
//Parameter   : PPNODE,PPNODE
//Return      : void
//Description : Used to Count No of Nodes in a Linked List. 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

int Count(PNODE Head,PNODE Tail)
{
	int iCnt = 0;
	do
	{
		iCnt++;
		Head = Head->next;
	}
	while(Head != Tail->next);
	
	return iCnt;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : Display
//Parameter   : PPNODE,PPNODE
//Return      : void
//Description : Used to Display Nodes in a Linked List. 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void Display(PNODE Head,PNODE Tail)
{
	do
	{
		printf("|%d|=>",Head->data);
		Head = Head->next;
	}
	while(Head != Tail->next);
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : InsertFirst
//Parameter   : PPNODE,PPNODE,int
//Return      : void
//Description : Used to Insert Node At First Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void InsertFirst(PPNODE Head,PPNODE Tail,int iValue)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	newn->data = iValue;
	newn->next = NULL;
	
	if((*Head == NULL)&&(*Tail == NULL))
	{
		*Head = newn;
		*Tail = newn;
	}
	else
	{
		newn->next = *Head;
		*Head = newn;
	}
	(*Tail)->next = *Head;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : InsertLast
//Parameter   : PPNODE,PPNODE,int
//Return      : void
//Description : Used to Insert Node At Last Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void InsertLast(PPNODE Head,PPNODE Tail,int iValue)
{
	PNODE newn = NULL;
	newn = (PNODE)malloc(sizeof(NODE));
	newn->data = iValue;
	newn->next = NULL;
	
	if((*Head == NULL) && (*Tail == NULL))
	{
		*Head = newn;
		*Tail = newn;
	}
	else
	{
		(*Tail)->next = newn;
		(*Tail) = (*Tail)->next;
	}
	(*Tail)->next = *Head;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : InsertAtPosition
//Parameter   : PPNODE,PPNODE,int,int
//Return      : void
//Description : Used to Insert Node At Given Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void InsertAtPosition(PPNODE Head,PPNODE Tail,int iValue,int iPos)
{
	PNODE newn = NULL;
	PNODE temp = *Head;
	newn = (PNODE)malloc(sizeof(PNODE));
	newn->data = iValue;
	newn->next = NULL;
	
	int iSize = Count(*Head,*Tail);
	
	if(iPos < 1 || iPos > iSize+1)
	{
		printf("Error: Invalid Position");
		return;
	}
	
	if(iPos == 1)
	{
		InsertFirst(Head,Tail,iValue);
	}
	else if(iPos == (iSize+1))
	{
		InsertLast(Head,Tail,iValue);
	}
	else
	{
		for(int i = 1 ; i<iPos-1 ; i++)
		{
			temp = temp->next;
		}
		
		newn->next = temp->next;
		temp->next = newn;
	}
	(*Tail)->next = *Head;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : DeleteFirst
//Parameter   : PPNODE,PPNODE
//Return      : void
//Description : Used to Delete Node At First Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void DeleteFirst(PPNODE Head,PPNODE Tail)
{
	PNODE temp = *Head;
	
	if((*Head == NULL) && (*Tail == NULL))
	{
		printf("Linked List is Empty");
		return;
	}
	else if((*Head)->next == NULL)
	{
		free(*Head);
		*Head = NULL;
	}
	else
	{
		*Head = temp->next;
		free(temp);
	}
	(*Tail)->next = *Head;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : DeleteLast
//Parameter   : PPNODE,PPNODE
//Return      : void
//Description : Used to Delete Node At Last Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void DeleteLast(PPNODE Head,PPNODE Tail)
{
	PNODE temp = *Tail;
	
	int iSize = Count(*Head,*Tail);
	
	if((*Head == NULL) && (*Tail == NULL))
	{
		printf("Linked List is Empty");
		return;
	}
	else if((*Head)->next == NULL)
	{
		free(*Head);
		*Head = NULL;
		*Tail = NULL;
	}
	else
	{
		do
		{
			temp = temp->next;
		}
		while(temp->next->next != *Head);
		
		free(temp->next);
		*Tail = temp; 
	}
	(*Tail)->next = *Head;
}

/////////////////////////////////////////////////////////////////////////////
//
//Function    : DeleteAtPosition
//Parameter   : PPNODE,PPNODE,int
//Return      : void
//Description : Used to Delete Node At Given Position 
//Author      : Anand Deshmukh
//Date        : 12/09/2020
//
/////////////////////////////////////////////////////////////////////////////

void DeleteAtPosition(PPNODE Head,PPNODE Tail,int iPos)
{
	PNODE temp = *Head;
	
	int iSize = Count(*Head,*Tail);
	
	if(iPos < 1 || iPos > iSize)
	{
		printf("Invaid Input");
		return;
	}
	
	if(iPos == 1)
	{
		DeleteFirst(Head,Tail);
	}
	else if(iPos == iSize)
	{
		DeleteLast(Head,Tail);
	}
	else
	{
		for(int i = 1 ; i<iPos-1 ; i++)
		{
			temp = temp->next;
		}
		PNODE temp2 = temp->next;
		temp->next = temp2->next;
		free(temp2);
		
		(*Tail)->next = *Head;
	}
	
}

int main()
{
	PNODE FIRST = NULL;
	PNODE LAST = NULL;
	int iNo = 0;
	int iRet = 0;
	int iPos = 0;

	while(1)
	{
		printf("********MENU********\n");
		printf("\n1.Insert First");
		printf("\n2.Insert Last");
		printf("\n3.Insert At Position");
		printf("\n4.Delete First");
		printf("\n5.Delete Last");
		printf("\n6.Delete At Position");
		printf("\n7.Total Nodes in Linked List");
		printf("\n8.Display Linked List");
		printf("\n\nEnter Your Choice :");
		int choice = 0;
		scanf("%d",&choice);
		
		switch(choice)
		{
			
			case 1 :
					printf("\nEnter a Number:");
					scanf("%d",&iNo);
					InsertFirst(&FIRST,&LAST,iNo);
					Display(FIRST,LAST);
					break;
			case 2 :
					printf("\nEnter a Number:");
					scanf("%d",&iNo);
					InsertLast(&FIRST,&LAST,iNo);
					Display(FIRST,LAST);
					break;
			case 3 :
					printf("\nEnter a Number:");
					scanf("%d",&iNo);
					printf("\nEnter a Position:");
					scanf("%d",&iPos);
					InsertAtPosition(&FIRST,&LAST,iNo,iPos);
					Display(FIRST,LAST);
					break;
			case 4 :
					DeleteFirst(&FIRST,&LAST);
					Display(FIRST,LAST);
					break;
			case 5 :
					DeleteLast(&FIRST,&LAST);
					Display(FIRST,LAST);
					break;
			case 6 :
					printf("\nEnter a Position:");
					scanf("%d",&iPos);
					DeleteAtPosition(&FIRST,&LAST,iPos);
					Display(FIRST,LAST);
					break;
			
			case 7 :
					iRet = Count(FIRST,LAST);
					printf("\nCount is :%d",iRet);
					break;
			case 8 :
					Display(FIRST,LAST);
					break;
			default : 
					printf("\nInvalid Choice...");
					break;
		}
		
		int i = 0;
		printf("\nDo you want to continue,\nPress 1 otherwise Press 0\n");
		scanf("%d",&i);
		
		if(i == 0)
		{
			break;
		}
	}
	return 0;
}

